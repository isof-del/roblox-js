# Project status

This repository is best treated as an experimental compiler/toolchain project.

## Current strengths

- The codebase has a dedicated compiler/emitter instead of simple text substitution.
- A runtime compatibility module is included alongside generated output.
- The project has a browser playground and a Next.js application around the compiler.
- The compiler exposes both single-file and multi-file project entry points.

## Known direction

The project should prioritize correctness, diagnostics, test coverage, and documented compatibility boundaries before claiming production-grade JavaScript compatibility.

When adding language features, preserve source locations and prefer deterministic output so compiler regressions are easy to identify.
