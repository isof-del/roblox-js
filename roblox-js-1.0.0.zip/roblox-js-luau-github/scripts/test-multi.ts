import { compileProject } from "../src/compiler";

const multi = compileProject([
  { name: "util.js", content: `export function double(n) { return n * 2; }\nexport const VERSION = "1.2.3";\nexport default double;` },
  { name: "src/main.js", content: `import { double, VERSION } from "../util";\nimport util from "../util";\nconst arr = [1,2,3];\nfor (const v of arr) print(v);\nlet i = 0;\nwhile (i < 3) { i++; if (i === 2) continue; print("iter", i); }\nconst t = { hp: 5 };\nconst { hp, mp = 0 } = t;\nprint(hp, mp, typeof hp, hp === undefined, "end" in t);\nconst m = new Map(); m.set("a", 1); print(m.size);\nconst s = "hello"; print(s.length, s[1]);\nconsole.log(arr[0], arr.length);` },
], { projectName: "demo" });

for (const o of multi.outputs) {
  if (o.kind === "runtime") continue;
  console.log("===== " + o.path + " =====");
  console.log(o.content);
}
console.log("DIAGS:", JSON.stringify(multi.diagnostics, null, 1));
