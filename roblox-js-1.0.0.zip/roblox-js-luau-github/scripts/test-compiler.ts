import { compileFile } from "../src/compiler";
import { SAMPLES } from "../src/compiler/samples";

for (const sample of SAMPLES) {
  console.log("=".repeat(70));
  console.log("SAMPLE:", sample.name, `(${sample.id})`);
  console.log("=".repeat(70));
  const res = compileFile(sample.code, `${sample.id}.js`);
  console.log(res.code);
  if (res.diagnostics.length > 0) {
    console.log("--- DIAGNOSTICS ---");
    for (const d of res.diagnostics) {
      console.log(`[${d.severity}] ${d.line}:${d.column} ${d.message}`);
    }
  }
}
