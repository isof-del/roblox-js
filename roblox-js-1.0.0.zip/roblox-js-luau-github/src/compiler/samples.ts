export interface Sample {
  id: string;
  name: string;
  description: string;
  code: string;
}

export const SAMPLES: Sample[] = [
  {
    id: "part-spawner",
    name: "Part Spawner (Roblox)",
    description: "Services, events, Instance.new and the task scheduler.",
    code: `// Spawns a stream of glowing parts above the spawn location.
const Players = game.GetService("Players");
const COLORS = [Color3.fromRGB(255, 178, 36), Color3.fromRGB(61, 220, 151), Color3.fromRGB(255, 93, 93)];

let spawned = 0;
const MAX_PARTS = 12;

function makePart(index) {
	const part = Instance.new("Part");
	part.Name = "StreamPart_" + index;
	part.Anchored = true;
	part.Material = Enum.Material.Neon;
	part.Color = COLORS[index % COLORS.length];
	part.Size = new Vector3(2, 2, 2);
	part.Position = new Vector3(0, 10 + index, 0);
	part.Parent = workspace;
	return part;
}

task.spawn(() => {
	while (spawned < MAX_PARTS) {
		makePart(spawned);
		spawned += 1;
		task.wait(0.5);
	}
	const online = Players.GetPlayers();
	print(\`Spawned \${spawned} parts, \${online.length} players online\`);
});
`,
  },
  {
    id: "classes",
    name: "Classes & Inheritance",
    description: "Class lowering to metatables, super calls and methods.",
    code: `class Entity {
	name = "entity";
	health = 100;

	constructor(name) {
		if (name !== undefined) {
			this.name = name;
		}
	}

	describe() {
		return this.name + " @ " + this.health + " HP";
	}

	damage(amount) {
		this.health = Math.max(0, this.health - amount);
		return this.health > 0;
	}
}

class Boss extends Entity {
	phase = 1;

	constructor(name) {
		super(name);
		this.health = 500;
	}

	damage(amount) {
		const alive = super.damage(amount);
		if (alive && this.health < 250 && this.phase === 1) {
			this.phase = 2;
			print(this.name + " enters phase 2!");
		}
		return alive;
	}
}

const boss = new Boss("Moonlord");
boss.damage(120);
boss.damage(200);
console.log(boss.describe());
`,
  },
  {
    id: "collections",
    name: "Arrays, Maps & Strings",
    description: "Standard library calls lowered onto the runtime.",
    code: `const inventory = ["sword", "shield", "potion", "potion", "key"];

const unique = inventory.filter((item, i) => inventory.indexOf(item) === i);
console.log("unique:", unique.join(", "));

const counts = new Map();
for (const item of inventory) {
	counts.set(item, (counts.get(item) ?? 0) + 1);
}

for (const [item, count] of counts) {
	print(item + " x" + count);
}

const title = "  the lost kingdom  ";
console.log(title.trim().toUpperCase().replace("LOST", "FORGOTTEN"));
console.log("potion count:", counts.get("potion"));
`,
  },
  {
    id: "control-flow",
    name: "Control Flow & Errors",
    description: "Loops, switches, destructuring and try/catch.",
    code: `function fib(n) {
	let a = 0;
	let b = 1;
	for (let i = 0; i < n; i++) {
		[a, b] = [b, a + b];
	}
	return a;
}

function grade(score) {
	switch (Math.floor(score / 10)) {
		case 10:
		case 9:
			return "S";
		case 8:
			return "A";
		case 7:
			return "B";
		default:
			return "C";
	}
}

for (let i = 1; i <= 8; i++) {
	console.log(\`fib(\${i}) = \${fib(i)}\`);
}

try {
	const data = JSON.parse('{"hp": 42, "buffs": ["haste", "shield"]}');
	const { hp, buffs } = data;
	console.log("hp:", hp, "buffs:", buffs.join("+"));
} catch (err) {
	warn("bad save data", err);
}

console.log("grade(97) =", grade(97));
`,
  },
  {
    id: "hello",
    name: "Hello World",
    description: "The smallest possible roblox-java program.",
    code: `const target = "Roblox";
const parts = ["Hello", target + "!"];

for (let i = 0; i < 3; i++) {
	print(parts.join(", "));
}
`,
  },
];
