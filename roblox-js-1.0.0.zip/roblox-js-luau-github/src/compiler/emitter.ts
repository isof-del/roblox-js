import * as acorn from "acorn";
import type { Diagnostic } from "./types";

/* eslint-disable @typescript-eslint/no-explicit-any */
type Node = any;

// ---------------------------------------------------------------------------
// tables
// ---------------------------------------------------------------------------

const LUAU_KEYWORDS = new Set([
  "and", "break", "do", "else", "elseif", "end", "false", "for", "function",
  "if", "in", "local", "nil", "not", "or", "repeat", "return", "then",
  "true", "until", "while", "continue", "self",
]);

/** Globals that exist in a Roblox Luau environment and pass through. */
const ROBLOX_GLOBALS = new Set([
  "game", "workspace", "script", "shared", "_G", "Enum", "Instance", "task",
  "print", "warn", "tick", "time", "typeof", "type", "pairs", "ipairs",
  "next", "pcall", "xpcall", "require", "tostring", "tonumber", "select",
  "assert", "error", "getmetatable", "setmetatable", "rawget", "rawset",
  "rawequal", "rawlen", "math", "string", "table", "os", "bit32", "utf8",
  "debug", "wait", "spawn", "delay", "settings", "UserSettings",
  "Vector3", "Vector2", "Vector2int16", "Vector3int16", "CFrame", "Color3",
  "UDim2", "UDim", "Rect", "Region3", "Region3int16", "NumberRange",
  "NumberSequence", "NumberSequenceKeypoint", "ColorSequence",
  "ColorSequenceKeypoint", "BrickColor", "TweenInfo", "Ray", "RaycastParams",
  "OverlapParams", "Random", "Axes", "Faces", "PhysicalProperties", "Font",
  "DateTime", "PathWaypoint", "DockWidgetPluginGuiInfo", "CatalogSearchParams",
  "FloatCurve", "RotationCurve", "SharedTable", "buffer", "plugin",
]);

/** Identifiers whose member calls use colon syntax (Roblox instances). */
const COLON_ROOTS = new Set(["game", "workspace", "script", "Enum"]);

/** Library tables whose member calls always use dot syntax. */
const DOT_ROOTS = new Set([
  "math", "string", "table", "os", "task", "bit32", "utf8", "debug",
  "Instance", "buffer", "SharedTable", "settings", "UserSettings",
]);

/** `new X(...)` -> `X.new(...)` for Roblox data types. */
const DATATYPES = new Set([
  "Vector3", "Vector2", "Vector2int16", "Vector3int16", "CFrame", "Color3",
  "UDim2", "UDim", "Rect", "Region3", "Region3int16", "NumberRange",
  "NumberSequence", "NumberSequenceKeypoint", "ColorSequence",
  "ColorSequenceKeypoint", "BrickColor", "TweenInfo", "Ray", "RaycastParams",
  "OverlapParams", "Random", "Axes", "Faces", "PhysicalProperties", "Font",
  "DateTime", "PathWaypoint", "DockWidgetPluginGuiInfo",
]);

const MATH_MAP: Record<string, string> = {
  floor: "math.floor", ceil: "math.ceil", abs: "math.abs", sqrt: "math.sqrt",
  max: "math.max", min: "math.min", log: "math.log", exp: "math.exp",
  sin: "math.sin", cos: "math.cos", tan: "math.tan", asin: "math.asin",
  acos: "math.acos", atan: "math.atan", atan2: "math.atan2", sinh: "math.sinh",
  cosh: "math.cosh", tanh: "math.tanh", fmod: "math.fmod", random: "math.random",
};

const ARRAY_METHODS: Record<string, string> = {
  push: "array_push", pop: "array_pop", shift: "array_shift",
  unshift: "array_unshift", indexOf: "array_indexOf",
  lastIndexOf: "array_lastIndexOf", includes: "array_includes",
  join: "array_join", slice: "array_slice", splice: "array_splice",
  reverse: "array_reverse", sort: "array_sort", map: "array_map",
  filter: "array_filter", reduce: "array_reduce",
  reduceRight: "array_reduceRight", forEach: "array_forEach",
  find: "array_find", findIndex: "array_findIndex", some: "array_some",
  every: "array_every", flat: "array_flat", fill: "array_fill",
};

const ARRAY_RETURNS_ARRAY = new Set([
  "map", "filter", "slice", "splice", "concat", "flat", "reverse", "sort",
]);

const STRING_METHODS: Record<string, string> = {
  indexOf: "str_indexOf", lastIndexOf: "str_lastIndexOf",
  includes: "str_includes", startsWith: "str_startsWith",
  endsWith: "str_endsWith", padStart: "str_padStart", padEnd: "str_padEnd",
  trim: "str_trim", trimStart: "str_trimStart", trimEnd: "str_trimEnd",
  split: "str_split", slice: "str_slice", substring: "str_substring",
  charAt: "str_charAt", charCodeAt: "str_charCodeAt",
  replace: "str_replace", replaceAll: "str_replaceAll",
};

const STRING_RETURNS_STRING = new Set([
  "trim", "trimStart", "trimEnd", "slice", "substring", "charAt", "replace",
  "replaceAll", "padStart", "padEnd", "concat", "toUpperCase", "toLowerCase",
  "repeat",
]);

/** Methods on Roblox instances that return instances (for inference). */
const INSTANCE_RETURNING = new Set([
  "GetService", "WaitForChild", "FindFirstChild", "FindFirstChildOfClass",
  "FindFirstChildWhichIsA", "Clone", "GetActor",
]);

/** Methods on Roblox instances that return arrays (for inference). */
const INSTANCE_ARRAY_RETURNING = new Set([
  "GetPlayers", "GetChildren", "GetDescendants", "GetAttributes", "GetTags",
  "GetWaypoints", "GetGamepadsConnectedTo", "GetJoints",
]);

interface FnCtx {
  kind: "function" | "arrow" | "method" | "constructor" | "static";
  className?: string;
}

interface LoopCtx {
  flag?: string;
}

interface SwitchCtx {
  endLabel: string;
  loopDepth: number;
}

function dirSegments(fileName: string): string[] {
  const parts = fileName.split("/");
  parts.pop();
  return parts;
}

export interface EmitterOptions {
  fileName?: string;
}

// ---------------------------------------------------------------------------
// Emitter
// ---------------------------------------------------------------------------

export class Emitter {
  diagnostics: Diagnostic[] = [];
  stats = { statements: 0, expressions: 0, locals: 0 };

  private buf: string[] = [];
  private indent = 0;
  private tempSeq = 0;
  private scopes: Map<string, string>[] = [];
  private fnStack: FnCtx[] = [];
  private loopStack: LoopCtx[] = [];
  private switchStack: SwitchCtx[] = [];
  private classCtx: { name: string; parent?: string; isStatic: boolean } | null = null;
  private classNames = new Set<string>();
  private parentOf = new Map<string, string>();
  private exported: { name: string; local: string }[] = [];
  private hasDefault = false;
  private replacements = new Map<Node, string>();
  private fileName: string;

  constructor(opts: EmitterOptions = {}) {
    this.fileName = opts.fileName ?? "main.js";
  }

  // -- low level ------------------------------------------------------------

  private write(line: string) {
    if (line === "") {
      this.buf.push("");
    } else {
      this.buf.push("\t".repeat(this.indent) + line);
    }
  }

  private diag(node: Node, severity: Diagnostic["severity"], message: string) {
    const loc = node?.loc?.start ?? { line: 1, column: 0 };
    this.diagnostics.push({
      severity,
      message,
      line: loc.line,
      column: loc.column,
      file: this.fileName,
    });
  }

  private fresh(prefix: string) {
    this.tempSeq += 1;
    return `__${prefix}${this.tempSeq}`;
  }

  private id(name: string): string {
    if (LUAU_KEYWORDS.has(name)) return `${name}_`;
    return name;
  }

  // -- scope & inference ------------------------------------------------------

  private pushScope() {
    this.scopes.push(new Map());
  }

  private popScope() {
    this.scopes.pop();
  }

  private declare(name: string, type = "unknown") {
    const frame = this.scopes[this.scopes.length - 1];
    if (frame) frame.set(name, type);
    this.stats.locals += 1;
  }

  private lookupType(name: string): string {
    for (let i = this.scopes.length - 1; i >= 0; i -= 1) {
      const t = this.scopes[i].get(name);
      if (t) return t;
    }
    if (ROBLOX_GLOBALS.has(name)) {
      if (COLON_ROOTS.has(name)) return "instance";
      if (DOT_ROOTS.has(name)) return "library";
      return "global";
    }
    return "unknown";
  }

  private isDeclared(name: string): boolean {
    return this.scopes.some((s) => s.has(name));
  }

  private setType(name: string, type: string) {
    for (let i = this.scopes.length - 1; i >= 0; i -= 1) {
      if (this.scopes[i].has(name)) {
        this.scopes[i].set(name, type);
        return;
      }
    }
  }

  private hasSideEffects(node: Node): boolean {
    if (!node || typeof node !== "object") return false;
    switch (node.type) {
      case "CallExpression":
      case "NewExpression":
      case "UpdateExpression":
      case "AssignmentExpression":
      case "YieldExpression":
      case "AwaitExpression":
        return true;
      default:
        for (const key of Object.keys(node)) {
          if (key === "loc" || key === "start" || key === "end") continue;
          const v = (node as any)[key];
          if (Array.isArray(v)) {
            for (const c of v) if (c && c.type && this.hasSideEffects(c)) return true;
          } else if (v && v.type && this.hasSideEffects(v)) {
            return true;
          }
        }
        return false;
    }
  }

  private containsType(node: Node, type: string): boolean {
    if (!node || typeof node !== "object") return false;
    if (node.type === type) return true;
    for (const key of Object.keys(node)) {
      if (key === "loc" || key === "start" || key === "end") continue;
      const v = node[key];
      if (Array.isArray(v)) {
        for (const c of v) if (c && c.type && this.containsType(c, type)) return true;
      } else if (v && v.type && this.containsType(v, type)) {
        return true;
      }
    }
    return false;
  }

  /** Nearest loop "continue target" flag, if the innermost loop is wrapped. */
  private innermostLoopFlag(): string | undefined {
    return this.loopStack[this.loopStack.length - 1]?.flag;
  }

  // -- entry point ------------------------------------------------------------

  emitProgram(source: string): string {
    let ast: Node;
    try {
      ast = acorn.parse(source, {
        ecmaVersion: 2022,
        sourceType: "module",
        locations: true,
      });
    } catch (e: any) {
      const loc = e?.loc ?? { line: 1, column: 0 };
      this.diagnostics.push({
        severity: "error",
        message: `Syntax error: ${e?.message ?? "invalid JavaScript"}`,
        line: loc.line,
        column: loc.column,
        file: this.fileName,
      });
      return `--[[ roblox-java: compilation failed (syntax error) ]]
error("roblox-java: syntax error in ${this.fileName}")
`;
    }

    this.pushScope();
    this.prepassClasses(ast);
    for (const stmt of ast.body) this.emitStatement(stmt);
    this.popScope();

    if (this.exported.length > 0 || this.hasDefault) {
      this.write("");
      const entries = this.exported.map(
        (e) => `${LUAU_KEYWORDS.has(e.name) ? `["${e.name}"]` : this.id(e.name)} = ${this.id(e.local)}`,
      );
      this.write("return {");
      this.indent += 1;
      for (const e of entries) this.write(`${e},`);
      this.indent -= 1;
      this.write("}");
    }

    return this.buf.join("\n") + "\n";
  }

  private prepassClasses(node: Node) {
    const visit = (n: Node) => {
      if (!n || typeof n !== "object") return;
      if (n.type === "ClassDeclaration" && n.id?.name) {
        this.classNames.add(n.id.name);
        if (n.superClass?.type === "Identifier") this.parentOf.set(n.id.name, n.superClass.name);
      }
      if (n.type === "ClassExpression" && n.id?.name) {
        this.classNames.add(n.id.name);
        if (n.superClass?.type === "Identifier") this.parentOf.set(n.id.name, n.superClass.name);
      }
      for (const key of Object.keys(n)) {
        if (key === "loc" || key === "start" || key === "end") continue;
        const v = n[key];
        if (Array.isArray(v)) v.forEach((c: Node) => c && c.type && visit(c));
        else if (v && v.type) visit(v);
      }
    };
    visit(node);
  }

  // -- statements ---------------------------------------------------------------

  private emitStatement(node: Node): void {
    this.stats.statements += 1;
    switch (node.type) {
      case "VariableDeclaration": return this.emitVariableDeclaration(node);
      case "FunctionDeclaration": return this.emitFunctionDeclaration(node);
      case "ClassDeclaration": return this.emitClassDeclaration(node);
      case "ExpressionStatement": return this.emitExpressionStatement(node);
      case "BlockStatement": return this.emitBlock(node);
      case "IfStatement": return this.emitIf(node);
      case "WhileStatement": return this.emitWhile(node);
      case "DoWhileStatement": return this.emitDoWhile(node);
      case "ForStatement": return this.emitFor(node);
      case "ForInStatement": return this.emitForIn(node);
      case "ForOfStatement": return this.emitForOf(node);
      case "ReturnStatement":
        return this.write(node.argument ? `return ${this.expr(node.argument)}` : "return");
      case "BreakStatement": return this.emitBreak();
      case "ContinueStatement": return this.emitContinue();
      case "ThrowStatement": return this.write(`error(${this.expr(node.argument)}, 0)`);
      case "TryStatement": return this.emitTry(node);
      case "SwitchStatement": return this.emitSwitch(node);
      case "EmptyStatement": return;
      case "ImportDeclaration": return this.emitImport(node);
      case "ExportNamedDeclaration": return this.emitExportNamed(node);
      case "ExportDefaultDeclaration": return this.emitExportDefault(node);
      case "ExportAllDeclaration":
        this.diag(node, "error", "export * is not supported by roblox-java");
        return;
      case "LabeledStatement":
        this.diag(node, "error", "labeled statements are not supported");
        return this.emitStatement(node.body);
      case "WithStatement":
        this.diag(node, "error", "with statements are not supported");
        return this.emitStatement(node.body);
      case "DebuggerStatement":
        this.diag(node, "warning", "debugger statements are ignored");
        return this.write("-- debugger (ignored)");
      default:
        this.diag(node, "error", `unsupported statement: ${node.type}`);
        return this.write(`--[[ unsupported statement: ${node.type} ]]`);
    }
  }

  private emitBlock(node: Node) {
    this.pushScope();
    for (const s of node.body) this.emitStatement(s);
    this.popScope();
  }

  private emitBlockBody(body: Node[]) {
    for (const s of body) this.emitStatement(s);
  }

  private emitVariableDeclaration(node: Node) {
    if (node.kind === "var") {
      this.diag(node, "info", "var is treated as block-scoped (local)");
    }
    for (const decl of node.declarations) {
      const init = decl.init ? this.expr(decl.init) : "nil";
      const initType = decl.init ? this.typeOfExpr(decl.init) : "unknown";
      this.emitBinding(decl.id, init, initType);
    }
  }

  /** Bind a pattern to an expression, declaring locals. */
  private emitBinding(pattern: Node, initExpr: string, initType: string) {
    if (pattern.type === "Identifier") {
      this.declare(pattern.name, initType);
      this.write(`local ${this.id(pattern.name)} = ${initExpr}`);
      return;
    }
    const tmp = this.fresh("d");
    this.write(`local ${tmp} = ${initExpr}`);
    this.emitDestructure(pattern, tmp, true);
  }

  private emitDestructure(pattern: Node, src: string, declareLocal: boolean) {
    if (pattern.type === "ArrayPattern") {
      let index = 0;
      for (let i = 0; i < pattern.elements.length; i += 1) {
        const el = pattern.elements[i];
        if (!el) {
          index += 1;
          continue;
        }
        if (el.type === "RestElement") {
          const arg = el.argument;
          const slice = `__rojava.array_slice(${src}, ${index})`;
          if (arg.type === "Identifier") {
            if (declareLocal) this.declare(arg.name, "array");
            this.write(`${declareLocal ? "local " : ""}${this.id(arg.name)} = ${slice}`);
          } else {
            const t2 = this.fresh("d");
            this.write(`local ${t2} = ${slice}`);
            this.emitDestructure(arg, t2, declareLocal);
          }
          break;
        }
        let value = `${src}[${index + 1}]`;
        let target = el;
        if (el.type === "AssignmentPattern") {
          value = `${src}[${index + 1}]`;
          target = el.left;
        }
        if (target.type === "Identifier") {
          if (declareLocal) this.declare(target.name, "unknown");
          this.write(`${declareLocal ? "local " : ""}${this.id(target.name)} = ${value}`);
          if (el.type === "AssignmentPattern") {
            this.write(`if ${this.id(target.name)} == nil then`);
            this.indent += 1;
            this.write(`${this.id(target.name)} = ${this.expr(el.right)}`);
            this.indent -= 1;
            this.write("end");
          }
        } else {
          const t2 = this.fresh("d");
          this.write(`local ${t2} = ${value}`);
          this.emitDestructure(target, t2, declareLocal);
        }
        index += 1;
      }
      return;
    }
    if (pattern.type === "ObjectPattern") {
      for (const prop of pattern.properties) {
        if (prop.type === "RestElement") {
          this.diag(prop, "warning", "object rest patterns are not supported; skipped");
          continue;
        }
        const key = prop.computed
          ? `[${this.expr(prop.key)}]`
          : prop.key.type === "Identifier"
            ? `.${this.id(prop.key.name)}`
            : `["${prop.key.value}"]`;
        let target = prop.value;
        let def: Node | null = null;
        if (target.type === "AssignmentPattern") {
          def = target.right;
          target = target.left;
        }
        if (target.type === "Identifier") {
          if (declareLocal) this.declare(target.name, "unknown");
          this.write(`${declareLocal ? "local " : ""}${this.id(target.name)} = ${src}${key}`);
          if (def) {
            this.write(`if ${this.id(target.name)} == nil then`);
            this.indent += 1;
            this.write(`${this.id(target.name)} = ${this.expr(def)}`);
            this.indent -= 1;
            this.write("end");
          }
        } else {
          const t2 = this.fresh("d");
          this.write(`local ${t2} = ${src}${key}`);
          this.emitDestructure(target, t2, declareLocal);
        }
      }
      return;
    }
    this.diag(pattern, "error", `unsupported binding pattern: ${pattern.type}`);
  }

  private emitExpressionStatement(node: Node) {
    const e = node.expression;
    if (e.type === "AssignmentExpression") {
      this.emitAssignmentStatement(e);
      return;
    }
    if (e.type === "UpdateExpression") {
      this.emitUpdate(e, false);
      return;
    }
    if (e.type === "UnaryExpression" && e.operator === "delete") {
      this.emitDelete(e.argument);
      return;
    }
    this.write(this.expr(e));
  }

  private emitDelete(arg: Node) {
    if (arg.type === "MemberExpression") {
      const obj = this.memberBase(arg);
      const key = this.memberKey(arg);
      this.write(`${obj}${key} = nil`);
    } else {
      this.diag(arg, "warning", "delete is only supported on member expressions");
      this.write("-- unsupported delete target");
    }
  }

  private emitBreak() {
    const sw = this.switchStack[this.switchStack.length - 1];
    if (sw && this.loopStack.length === sw.loopDepth) {
      this.write(`goto ${sw.endLabel}`);
      return;
    }
    const flag = this.innermostLoopFlag();
    if (flag) {
      this.write(`${flag} = true`);
    }
    this.write("break");
  }

  private emitContinue() {
    const flag = this.innermostLoopFlag();
    if (flag) {
      this.write("break");
      return;
    }
    this.diag({ loc: null } as any, "error", "continue could not be lowered");
    this.write("-- continue (not lowered)");
  }

  // -- control flow -------------------------------------------------------------

  private emitIf(node: Node) {
    let current: Node = node;
    let first = true;
    while (current) {
      const kw = first ? "if" : "elseif";
      this.write(`${kw} ${this.expr(current.test)} then`);
      this.indent += 1;
      if (current.consequent.type === "BlockStatement") this.emitBlockBody(current.consequent.body);
      else this.emitStatement(current.consequent);
      this.indent -= 1;
      first = false;
      if (current.alternate && current.alternate.type === "IfStatement") {
        current = current.alternate;
        continue;
      }
      if (current.alternate) {
        this.write("else");
        this.indent += 1;
        if (current.alternate.type === "BlockStatement") this.emitBlockBody(current.alternate.body);
        else this.emitStatement(current.alternate);
        this.indent -= 1;
      }
      break;
    }
    this.write("end");
  }

  private emitLoopBody(
    body: Node,
    opts: { before?: string[]; after?: string[] } = {},
  ): void {
    const needsContinue = this.containsType(body, "ContinueStatement");
    if (!needsContinue) {
      if (opts.before) for (const l of opts.before) this.write(l);
      this.emitStatement(body);
      if (opts.after) for (const l of opts.after) this.write(l);
      return;
    }
    const flag = this.fresh("brk");
    this.write(`local ${flag} = false`);
    this.loopStack.push({ flag });
    if (opts.before) for (const l of opts.before) this.write(l);
    this.write("repeat");
    this.indent += 1;
    this.emitStatement(body);
    this.indent -= 1;
    this.write("until true");
    if (opts.after) for (const l of opts.after) this.write(l);
    this.write(`if ${flag} then`);
    this.indent += 1;
    this.write("break");
    this.indent -= 1;
    this.write("end");
    this.loopStack.pop();
  }

  private emitWhile(node: Node) {
    this.write(`while ${this.expr(node.test)} do`);
    this.indent += 1;
    this.loopStack.push({});
    this.emitLoopBody(node.body);
    this.loopStack.pop();
    this.indent -= 1;
    this.write("end");
  }

  private emitDoWhile(node: Node) {
    const needsContinue = this.containsType(node.body, "ContinueStatement");
    this.write("repeat");
    this.indent += 1;
    this.loopStack.push({});
    if (needsContinue) {
      this.emitLoopBody(node.body);
    } else {
      this.emitStatement(node.body);
    }
    this.loopStack.pop();
    this.indent -= 1;
    this.write(`until not (${this.expr(node.test)})`);
  }

  /** Detect `for (let i = a; i < b; i++)` and lower to a numeric for. */
  private tryNumericFor(node: Node): boolean {
    const init = node.init;
    if (!init || init.type !== "VariableDeclaration" || init.declarations.length !== 1) return false;
    const decl = init.declarations[0];
    if (decl.id.type !== "Identifier" || !decl.init || decl.init.type !== "Literal") return false;
    if (typeof decl.init.value !== "number") return false;
    const name = decl.id.name;
    const test = node.test;
    if (!test || test.type !== "BinaryExpression") return false;
    if (test.operator !== "<" && test.operator !== "<=") return false;
    if (test.left.type !== "Identifier" || test.left.name !== name) return false;
    const update = node.update;
    if (!update) return false;
    let step = 1;
    if (update.type === "UpdateExpression" && update.operator === "++" &&
        update.argument.type === "Identifier" && update.argument.name === name) {
      step = 1;
    } else if (update.type === "AssignmentExpression" && update.operator === "+=" &&
        update.left.type === "Identifier" && update.left.name === name &&
        update.right.type === "Literal" && typeof update.right.value === "number") {
      step = update.right.value;
    } else {
      return false;
    }
    if (this.containsType(node.body, "ContinueStatement")) return false;

    let limitExpr = this.expr(test.right);
    if (this.hasSideEffects(test.right)) {
      const tmp = this.fresh("limit");
      this.write(`local ${tmp} = ${limitExpr}`);
      limitExpr = tmp;
    }
    const limit = test.operator === "<" ? `${limitExpr} - 1` : limitExpr;
    this.declare(name, "number");
    const stepPart = step === 1 ? "" : `, ${step}`;
    this.write(`for ${this.id(name)} = ${decl.init.value}, ${limit}${stepPart} do`);
    this.indent += 1;
    this.loopStack.push({});
    this.emitStatement(node.body);
    this.loopStack.pop();
    this.indent -= 1;
    this.write("end");
    return true;
  }

  private emitFor(node: Node) {
    if (this.tryNumericFor(node)) return;
    this.pushScope();
    if (node.init) {
      if (node.init.type === "VariableDeclaration") this.emitVariableDeclaration(node.init);
      else this.write(this.expr(node.init));
    }
    const test = node.test ? this.expr(node.test) : "true";
    this.write(`while ${test} do`);
    this.indent += 1;
    this.loopStack.push({});
    const updateLines = node.update ? this.updateAsStatement(node.update) : undefined;
    this.emitLoopBody(node.body, { after: updateLines });
    this.loopStack.pop();
    this.indent -= 1;
    this.write("end");
    this.popScope();
  }

  private updateAsStatement(update: Node): string[] {
    const saved = this.buf;
    this.buf = [];
    if (update.type === "UpdateExpression") this.emitUpdate(update, false);
    else if (update.type === "AssignmentExpression") this.emitAssignmentStatement(update);
    else this.write(this.expr(update));
    const lines = this.buf;
    this.buf = saved;
    return lines;
  }

  private emitForIn(node: Node) {
    const obj = this.expr(node.right);
    this.pushScope();
    const binder = this.loopBinder(node.left, "for_k");
    this.write(`for ${binder}, _ in pairs(${obj}) do`);
    this.indent += 1;
    this.flushPendingDestructure();
    this.loopStack.push({});
    this.emitLoopBody(node.body);
    this.loopStack.pop();
    this.indent -= 1;
    this.write("end");
    this.popScope();
  }

  private emitForOf(node: Node) {
    const right = node.right;
    const rightType = this.typeOfExpr(right);
    const obj = this.expr(right);
    this.pushScope();
    const binder = this.loopBinder(node.left, "for_v");
    const iterator =
      rightType === "array" ? `ipairs(${obj})` : `__rojava.iter(${obj})`;
    const valueVar = binder.startsWith("__") ? binder : binder;
    this.write(`for _, ${valueVar} in ${iterator} do`);
    this.indent += 1;
    this.flushPendingDestructure();
    this.loopStack.push({});
    this.emitLoopBody(node.body);
    this.loopStack.pop();
    this.indent -= 1;
    this.write("end");
    this.popScope();
  }

  /** Declare loop variable(s); returns the Luau loop variable name. */
  private loopBinder(left: Node, prefix: string): string {
    if (left.type === "VariableDeclaration") {
      const d = left.declarations[0];
      if (d.id.type === "Identifier") {
        this.declare(d.id.name, "unknown");
        return this.id(d.id.name);
      }
      const tmp = this.fresh(prefix);
      this.pendingDestructure = { pattern: d.id, src: tmp };
      return tmp;
    }
    if (left.type === "Identifier") return this.id(left.name);
    const tmp = this.fresh(prefix);
    this.pendingDestructure = { pattern: left, src: tmp };
    return tmp;
  }

  private pendingDestructure: { pattern: Node; src: string } | null = null;

  private flushPendingDestructure() {
    if (!this.pendingDestructure) return;
    const { pattern, src } = this.pendingDestructure;
    this.pendingDestructure = null;
    this.emitDestructure(pattern, src, true);
  }

  private emitTry(node: Node) {
    const okVar = this.fresh("ok");
    const errVar = this.fresh("err");
    if (node.handler) {
      this.write(`local ${okVar}, ${errVar} = pcall(function()`);
    } else {
      this.write(`pcall(function()`);
    }
    this.indent += 1;
    this.emitBlockBody(node.block.body);
    this.indent -= 1;
    this.write("end)");
    if (node.handler) {
      this.write(`if not ${okVar} then`);
      this.indent += 1;
      this.pushScope();
      const param = node.handler.param;
      if (param) {
        if (param.type === "Identifier") {
          this.declare(param.name, "unknown");
          this.write(`local ${this.id(param.name)} = ${errVar}`);
        } else {
          this.diag(param, "warning", "catch binding patterns are not supported");
        }
      }
      this.emitBlockBody(node.handler.body.body);
      this.popScope();
      this.indent -= 1;
      this.write("end");
    }
    if (node.finalizer) {
      this.emitBlockBody(node.finalizer.body);
    }
    if (this.containsType(node.block, "ReturnStatement")) {
      this.diag(node, "warning", "return inside try blocks has limited support (pcall boundary)");
    }
  }

  private emitSwitch(node: Node) {
    const disc = this.fresh("sw");
    const fall = this.fresh("fall");
    const endLabel = this.fresh("sw_end");
    this.write(`local ${disc} = ${this.expr(node.discriminant)}`);
    this.write(`local ${fall} = false`);
    this.switchStack.push({ endLabel, loopDepth: this.loopStack.length });

    const cases = node.cases.filter((c: Node) => c.test !== null);
    const defaultCase = node.cases.find((c: Node) => c.test === null);

    for (const c of cases) {
      this.write(`if ${fall} or ${disc} == ${this.expr(c.test)} then`);
      this.indent += 1;
      this.write(`${fall} = true`);
      this.pushScope();
      for (const s of c.consequent) this.emitStatement(s);
      this.popScope();
      this.indent -= 1;
      this.write("end");
    }
    if (defaultCase) {
      this.pushScope();
      for (const s of defaultCase.consequent) this.emitStatement(s);
      this.popScope();
    }
    this.switchStack.pop();
    this.write(`::${endLabel}::`);
  }

  // -- functions & classes -------------------------------------------------------

  private emitFunctionDeclaration(node: Node) {
    const name = node.id ? node.id.name : this.fresh("fn");
    this.declare(name, "function");
    const body = this.buildFunctionBody(node.params, node.body, {
      kind: "function",
      name,
    });
    this.write(`local function ${this.id(name)}(${body.params})`);
    this.indent += 1;
    for (const l of body.prelude) this.write(l);
    for (const l of body.lines) this.write(l);
    this.indent -= 1;
    this.write("end");
  }

  private buildFunctionBody(
    params: Node[],
    body: Node,
    ctx: { kind: FnCtx["kind"]; name?: string; className?: string },
  ): { params: string; prelude: string[]; lines: string[] } {
    const savedBuf = this.buf;
    const savedIndent = this.indent;
    this.buf = [];
    this.indent = 0;

    this.pushScope();
    this.fnStack.push({ kind: ctx.kind, className: ctx.className });

    const paramNames: string[] = [];
    const prelude: string[] = [];
    for (const p of params) {
      if (p.type === "Identifier") {
        this.declare(p.name, "unknown");
        paramNames.push(this.id(p.name));
      } else if (p.type === "AssignmentPattern") {
        if (p.left.type === "Identifier") {
          this.declare(p.left.name, "unknown");
          paramNames.push(this.id(p.left.name));
          const name = this.id(p.left.name);
          prelude.push(`if ${name} == nil then`);
          prelude.push(`\t${name} = ${this.expr(p.right)}`);
          prelude.push("end");
        } else {
          const tmp = this.fresh("p");
          paramNames.push(tmp);
          const sub = this.captureDestructure(p.left, tmp, prelude);
          void sub;
        }
      } else if (p.type === "RestElement") {
        if (p.argument.type === "Identifier") {
          this.declare(p.argument.name, "array");
          paramNames.push("...");
          prelude.push(`local ${this.id(p.argument.name)} = table.pack(...)`);
        } else {
          this.diag(p, "error", "unsupported rest parameter pattern");
        }
      } else if (p.type === "ObjectPattern" || p.type === "ArrayPattern") {
        const tmp = this.fresh("p");
        paramNames.push(tmp);
        this.captureDestructure(p, tmp, prelude);
      } else {
        this.diag(p, "error", `unsupported parameter: ${p.type}`);
      }
    }

    if (body.type === "BlockStatement") {
      this.emitBlockBody(body.body);
    } else {
      this.write(`return ${this.expr(body)}`);
    }

    this.fnStack.pop();
    this.popScope();

    const lines = this.buf;
    this.buf = savedBuf;
    this.indent = savedIndent;
    return { params: paramNames.join(", "), prelude, lines };
  }

  /** Lower a destructured parameter into prelude lines. */
  private captureDestructure(pattern: Node, src: string, prelude: string[]) {
    const savedBuf = this.buf;
    const savedIndent = this.indent;
    this.buf = [];
    this.indent = 0;
    this.emitDestructure(pattern, src, true);
    prelude.push(...this.buf);
    this.buf = savedBuf;
    this.indent = savedIndent;
  }

  private emitClassDeclaration(node: Node) {
    const name = node.id?.name ?? this.fresh("Class");
    this.declare(name, `class:${name}`);
    const lines = this.buildClass(name, node);
    for (const l of lines) this.write(l);
  }

  private buildClass(name: string, node: Node): string[] {
    const savedBuf = this.buf;
    const savedIndent = this.indent;
    this.buf = [];
    this.indent = 0;

    const parent = node.superClass?.type === "Identifier" ? node.superClass.name : undefined;
    if (node.superClass && !parent) {
      this.diag(node.superClass, "warning", "non-identifier superclasses are not supported");
    }
    const safeName = this.id(name);

    if (parent) {
      this.write(`local ${safeName} = setmetatable({}, ${this.id(parent)})`);
    } else {
      this.write(`local ${safeName} = {}`);
    }
    this.write(`${safeName}.__index = ${safeName}`);
    this.write("");

    const ctor = node.body.body.find(
      (m: Node) => m.type === "MethodDefinition" && m.kind === "constructor",
    );
    const instanceFields = node.body.body.filter(
      (m: Node) => m.type === "PropertyDefinition" && !m.static,
    );
    const staticFields = node.body.body.filter(
      (m: Node) => m.type === "PropertyDefinition" && m.static,
    );
    const staticMethods = node.body.body.filter(
      (m: Node) => m.type === "MethodDefinition" && m.static,
    );
    const instanceMethods = node.body.body.filter(
      (m: Node) => m.type === "MethodDefinition" && m.kind === "method" && !m.static,
    );
    for (const m of node.body.body) {
      if (m.type === "MethodDefinition" && (m.kind === "get" || m.kind === "set")) {
        this.diag(m, "error", "class getters/setters are not supported by roblox-java");
      }
      if (m.type === "StaticBlock") {
        this.diag(m, "error", "static blocks are not supported by roblox-java");
      }
    }

    // constructor
    this.write(`function ${safeName}.new(self, ...)`);
    this.indent += 1;
    this.write("if self == nil then");
    this.indent += 1;
    this.write(`self = setmetatable({}, ${safeName})`);
    this.indent -= 1;
    this.write("end");
    if (parent) {
      const hasSuperCall = ctor ? this.containsType(ctor.value.body, "CallExpression") &&
        this.findSuperCall(ctor.value.body) : false;
      if (!hasSuperCall) {
        this.write(`${this.id(parent)}.new(self, ...)`);
      }
    }
    this.classCtx = { name, parent, isStatic: false };
    this.pushScope();
    this.fnStack.push({ kind: "constructor", className: name });
    this.declare("self", `class:${name}`);
    if (ctor) {
      this.emitCtorParamBindings(ctor.value.params);
    }
    for (const f of instanceFields) {
      const key = this.fieldKey(f);
      this.write(`self${key} = ${f.value ? this.expr(f.value) : "nil"}`);
    }
    if (ctor) {
      this.emitCtorBody(ctor.value, parent);
    }
    this.fnStack.pop();
    this.popScope();
    this.write("return self");
    this.indent -= 1;
    this.write("end");

    // instance methods
    for (const m of instanceMethods) {
      const mname = this.methodName(m);
      this.classCtx = { name, parent, isStatic: false };
      this.superMode = parent ? { parent, inCtor: false } : undefined;
      const body = this.buildFunctionBody(m.value.params, m.value.body, {
        kind: "method",
        className: name,
      });
      this.superMode = undefined;
      this.classCtx = null;
      this.write("");
      this.write(`function ${safeName}:${mname}(${body.params})`);
      this.indent += 1;
      for (const l of body.prelude) this.write(l);
      for (const l of body.lines) this.write(l);
      this.indent -= 1;
      this.write("end");
    }

    // static methods
    for (const m of staticMethods) {
      const mname = this.methodName(m);
      this.classCtx = { name, parent, isStatic: true };
      this.superMode = parent ? { parent, inCtor: false } : undefined;
      const body = this.buildFunctionBody(m.value.params, m.value.body, {
        kind: "static",
        className: name,
      });
      this.superMode = undefined;
      this.classCtx = null;
      this.write("");
      this.write(`function ${safeName}.${mname}(${body.params})`);
      this.indent += 1;
      for (const l of body.prelude) this.write(l);
      for (const l of body.lines) this.write(l);
      this.indent -= 1;
      this.write("end");
    }

    // static fields
    for (const f of staticFields) {
      const key = this.fieldKey(f);
      this.write(`${safeName}${key} = ${f.value ? this.expr(f.value) : "nil"}`);
    }

    this.classCtx = null;
    this.superMode = undefined;
    const out = this.buf;
    this.buf = savedBuf;
    this.indent = savedIndent;
    return out;
  }

  private fieldKey(f: Node): string {
    if (f.computed) return `[${this.expr(f.key)}]`;
    if (f.key.type === "Identifier") return `.${this.id(f.key.name)}`;
    return `["${f.key.value}"]`;
  }

  private methodName(m: Node): string {
    if (m.computed) {
      this.diag(m, "warning", "computed method names are unsupported; using raw key");
    }
    if (m.key.type === "Identifier") return this.id(m.key.name);
    return String(m.key.value);
  }

  private fnParamsInline(fn: Node): string {
    const names: string[] = [];
    this.pushScope();
    for (const p of fn.params) {
      if (p.type === "Identifier") names.push(this.id(p.name));
      else if (p.type === "RestElement" && p.argument.type === "Identifier") names.push("...");
      else if (p.type === "AssignmentPattern" && p.left.type === "Identifier") names.push(this.id(p.left.name));
      else {
        names.push(this.fresh("p"));
      }
    }
    this.popScope();
    return names.join(", ");
  }

  private emitMethodBody(fn: Node, ctx: { kind: FnCtx["kind"]; className?: string }) {
    // Re-emit params with defaults inside the real body scope.
    this.pushScope();
    this.fnStack.push({ kind: ctx.kind, className: ctx.className });
    this.declare("self", ctx.kind === "static" ? "library" : "unknown");
    for (const p of fn.params) {
      if (p.type === "Identifier") {
        this.declare(p.name, "unknown");
      } else if (p.type === "AssignmentPattern" && p.left.type === "Identifier") {
        this.declare(p.left.name, "unknown");
        this.write(`if ${this.id(p.left.name)} == nil then`);
        this.indent += 1;
        this.write(`${this.id(p.left.name)} = ${this.expr(p.right)}`);
        this.indent -= 1;
        this.write("end");
      } else if (p.type === "RestElement" && p.argument.type === "Identifier") {
        this.declare(p.argument.name, "array");
        this.write(`local ${this.id(p.argument.name)} = table.pack(...)`);
      } else if (p.type === "ArrayPattern" || p.type === "ObjectPattern") {
        const tmp = this.fresh("p");
        this.write(`local ${tmp} = ...`);
        this.emitDestructure(p, tmp, true);
      }
    }
    this.emitBlockBody(fn.body.body);
    this.fnStack.pop();
    this.popScope();
  }

  private findSuperCall(body: Node): boolean {
    if (!body || typeof body !== "object") return false;
    if (body.type === "CallExpression" && body.callee?.type === "Super") return true;
    for (const key of Object.keys(body)) {
      if (key === "loc" || key === "start" || key === "end") continue;
      const v = body[key];
      if (Array.isArray(v)) {
        for (const c of v) if (c && c.type && this.findSuperCall(c)) return true;
      } else if (v && v.type && this.findSuperCall(v)) return true;
    }
    return false;
  }

  private emitCtorBody(fn: Node, parent?: string) {
    // Rewrite super(...) calls into Parent.new(self, ...)
    const savedExpr = this.superMode;
    this.superMode = parent ? { parent, inCtor: true } : undefined;
    this.emitBlockBody(fn.body.body);
    this.superMode = savedExpr;
  }

  /** Bind constructor parameters out of the forwarded varargs. */
  private emitCtorParamBindings(params: Node[]) {
    if (!params || params.length === 0) return;
    const args = this.fresh("args");
    this.write(`local ${args} = table.pack(...)`);
    let i = 1;
    for (const p of params) {
      if (p.type === "RestElement") {
        if (p.argument.type === "Identifier") {
          this.declare(p.argument.name, "array");
          this.write(`local ${this.id(p.argument.name)} = __rojava.array_slice(${args}, ${i - 1})`);
        }
        break;
      }
      let target = p;
      let def: Node | null = null;
      if (p.type === "AssignmentPattern") {
        def = p.right;
        target = p.left;
      }
      if (target.type === "Identifier") {
        this.declare(target.name, "unknown");
        this.write(`local ${this.id(target.name)} = ${args}[${i}]`);
        if (def) {
          this.write(`if ${this.id(target.name)} == nil then`);
          this.indent += 1;
          this.write(`${this.id(target.name)} = ${this.expr(def)}`);
          this.indent -= 1;
          this.write("end");
        }
      } else {
        const tmp = this.fresh("p");
        this.write(`local ${tmp} = ${args}[${i}]`);
        this.emitDestructure(target, tmp, true);
      }
      i += 1;
    }
  }

  private superMode: { parent: string; inCtor: boolean } | undefined;

  // -- imports / exports ----------------------------------------------------------

  private emitImport(node: Node) {
    const spec = node.source.value;
    const req = this.requireExprFor(spec, node);
    if (!req) return;
    if (node.specifiers.length === 0) {
      this.write(`require(${req})`);
      return;
    }
    const moduleName = this.fresh("mod");
    this.write(`local ${moduleName} = require(${req})`);
    for (const s of node.specifiers) {
      const localName = s.local.name;
      this.declare(localName, "module");
      if (s.type === "ImportDefaultSpecifier") {
        this.write(`local ${this.id(localName)} = ${moduleName}.default`);
      } else if (s.type === "ImportNamespaceSpecifier") {
        this.write(`local ${this.id(localName)} = ${moduleName}`);
      } else {
        const imported = s.imported.type === "Identifier" ? s.imported.name : s.imported.value;
        this.write(`local ${this.id(localName)} = ${moduleName}.${this.id(imported)}`);
      }
    }
  }

  private requireExprFor(spec: string, node: Node): string | null {
    if (!spec.startsWith(".")) {
      this.diag(node, "warning", `external module "${spec}" emitted as a raw require`);
      return `"${spec}"`;
    }
    const parts = this.fileName.split("/");
    parts.pop(); // drop file name -> dir segments
    const stack = [...parts];
    for (const seg of spec.split("/")) {
      if (seg === "." || seg === "") continue;
      if (seg === "..") {
        if (stack.length === 0) {
          this.diag(node, "error", `import "${spec}" escapes the project root`);
          return null;
        }
        stack.pop();
        continue;
      }
      stack.push(seg.replace(/\.js$/, ""));
    }
    const moduleName = this.id(stack[stack.length - 1] ?? "module");
    const targetDir = stack.slice(0, -1);
    const importerDir = dirSegments(this.fileName);
    let lcp = 0;
    while (
      lcp < importerDir.length &&
      lcp < targetDir.length &&
      importerDir[lcp] === targetDir[lcp]
    ) {
      lcp += 1;
    }
    const ups = importerDir.length - lcp;
    const downs = targetDir.slice(lcp);
    let path = "script";
    for (let i = 0; i <= ups; i += 1) path += ".Parent";
    for (const d of downs) path += `.${this.id(d)}`;
    return `${path}.${moduleName}`;
  }

  private emitExportNamed(node: Node) {
    if (node.declaration) {
      const before = this.exported.length;
      this.emitStatement(node.declaration);
      if (node.declaration.type === "VariableDeclaration") {
        for (const d of node.declaration.declarations) {
          if (d.id.type === "Identifier") this.exported.push({ name: d.id.name, local: d.id.name });
        }
      } else if (node.declaration.id?.name) {
        this.exported.push({ name: node.declaration.id.name, local: node.declaration.id.name });
      }
      void before;
      return;
    }
    for (const s of node.specifiers) {
      if (s.exported.name === "default") {
        this.hasDefault = true;
        this.write(`local __default = ${this.expr(s.local)}`);
        continue;
      }
      const local = s.local.type === "Identifier" ? s.local.name : s.local.value;
      const exported = s.exported.type === "Identifier" ? s.exported.name : s.exported.value;
      this.exported.push({ name: exported, local });
    }
    if (node.source) {
      this.diag(node, "warning", "export-from is not fully supported; use explicit imports");
    }
  }

  private emitExportDefault(node: Node) {
    this.hasDefault = true;
    const d = node.declaration;
    if (d.type === "FunctionDeclaration" && d.id) {
      this.emitStatement(d);
      this.write(`local __default = ${this.id(d.id.name)}`);
      return;
    }
    if (d.type === "ClassDeclaration" && d.id) {
      this.emitStatement(d);
      this.write(`local __default = ${this.id(d.id.name)}`);
      return;
    }
    this.write(`local __default = ${this.expr(d)}`);
  }

  // -- expressions ------------------------------------------------------------------

  private expr(node: Node): string {
    this.stats.expressions += 1;
    const replaced = this.replacements.get(node);
    if (replaced !== undefined) return replaced;
    switch (node.type) {
      case "Identifier": return this.exprIdentifier(node);
      case "Literal": return this.exprLiteral(node);
      case "TemplateLiteral": return this.exprTemplate(node);
      case "TaggedTemplateExpression":
        this.diag(node, "error", "tagged templates are not supported");
        return "nil";
      case "ArrayExpression": return this.exprArray(node);
      case "ObjectExpression": return this.exprObject(node);
      case "BinaryExpression": return this.exprBinary(node);
      case "LogicalExpression": return this.exprLogical(node);
      case "UnaryExpression": return this.exprUnary(node);
      case "UpdateExpression": return this.emitUpdateExpr(node);
      case "AssignmentExpression": return this.exprAssignment(node);
      case "ConditionalExpression": return this.exprConditional(node);
      case "CallExpression": return this.exprCall(node);
      case "ChainExpression": return this.exprChain(node);
      case "MemberExpression": return this.exprMember(node);
      case "NewExpression": return this.exprNew(node);
      case "FunctionExpression":
      case "ArrowFunctionExpression": return this.exprFunction(node);
      case "SequenceExpression": return this.exprSequence(node);
      case "SpreadElement":
        this.diag(node, "error", "unexpected spread element");
        return "nil";
      case "ThisExpression": return this.exprThis(node);
      case "Super":
        return this.exprSuperValue(node);
      case "AwaitExpression":
        this.diag(node, "error", "async/await is not supported; use task.* APIs");
        return this.expr(node.argument);
      case "YieldExpression":
        this.diag(node, "error", "generators are not supported");
        return "nil";
      case "MetaProperty":
        this.diag(node, "error", "import.meta is not supported");
        return "nil";
      case "ClassExpression": {
        const name = node.id?.name ?? this.fresh("Class");
        this.classNames.add(name);
        if (node.superClass?.type === "Identifier") this.parentOf.set(name, node.superClass.name);
        const lines = this.buildClass(name, node);
        return `(function()\n${lines.map((l) => "\t" + l).join("\n")}\n${"\t".repeat(this.indent + 1)}return ${this.id(name)}\n${"\t".repeat(this.indent)})()`;
      }
      default:
        this.diag(node, "error", `unsupported expression: ${node.type}`);
        return "nil";
    }
  }

  private exprIdentifier(node: Node): string {
    const n = node.name;
    if (n === "undefined" || n === "null") return "nil";
    if (n === "Infinity") return "math.huge";
    if (n === "NaN") return "(0 / 0)";
    if (n === "globalThis") return "_G";
    if (n === "console") {
      this.diag(node, "warning", "bare console value is not representable; use console.* methods");
      return "{}";
    }
    return this.id(n);
  }

  private exprLiteral(node: Node): string {
    if (node.regex) {
      this.diag(node, "error", "regular expressions are not supported");
      return `"${node.value}"`;
    }
    if (typeof node.value === "string") return this.quote(node.value);
    if (typeof node.value === "number") {
      if (node.raw && /^0[xXbBoO]/.test(node.raw)) return String(node.value);
      return String(node.value);
    }
    if (typeof node.value === "boolean") return node.value ? "true" : "false";
    if (node.bigint !== undefined) {
      this.diag(node, "error", "BigInt is not supported");
      return node.value ?? "0";
    }
    return "nil";
  }

  private quote(s: string): string {
    let out = "";
    for (const ch of s) {
      const code = ch.codePointAt(0)!;
      if (ch === "\\") out += "\\\\";
      else if (ch === '"') out += '\\"';
      else if (ch === "\n") out += "\\n";
      else if (ch === "\r") out += "\\r";
      else if (ch === "\t") out += "\\t";
      else if (code === 0) out += "\\0";
      else if (code < 32 || code === 127) out += `\\${code}`;
      else out += ch;
    }
    return `"${out}"`;
  }

  private exprTemplate(node: Node): string {
    const parts: string[] = [];
    const quasis = node.quasis;
    for (let i = 0; i < quasis.length; i += 1) {
      const cooked = quasis[i].value.cooked;
      if (cooked && cooked.length > 0) parts.push(this.quote(cooked));
      if (i < node.expressions.length) {
        parts.push(`__rojava.toStr(${this.expr(node.expressions[i])})`);
      }
    }
    if (parts.length === 0) return '""';
    if (parts.length === 1) return parts[0];
    return `(${parts.join(" .. ")})`;
  }

  private exprArray(node: Node): string {
    const hasSpread = node.elements.some((e: Node) => e && e.type === "SpreadElement");
    if (!hasSpread) {
      const items = node.elements.map((e: Node) => (e ? this.expr(e) : "nil"));
      return `{${items.join(", ")}}`;
    }
    const args = node.elements.map((e: Node) => {
      if (!e) return "nil";
      if (e.type === "SpreadElement") {
        const t = this.typeOfExpr(e.argument);
        return t === "array" ? this.expr(e.argument) : this.expr(e.argument);
      }
      return `{${this.expr(e)}}`;
    });
    return `__rojava.array_concat(${args.join(", ")})`;
  }

  private exprObject(node: Node): string {
    const hasSpread = node.properties.some((p: Node) => p.type === "SpreadElement");
    if (!hasSpread) {
      const entries: string[] = [];
      for (const p of node.properties) {
        let key: string;
        if (p.computed) key = `[${this.expr(p.key)}]`;
        else if (p.key.type === "Identifier") {
          key = LUAU_KEYWORDS.has(p.key.name) ? `["${p.key.name}"]` : p.key.name;
        } else key = `["${p.key.value}"]`;
        let value: string;
        if (p.value.type === "FunctionExpression" || (p.method && p.value.type === "FunctionExpression")) {
          value = this.exprFunction(p.value);
        } else {
          value = this.expr(p.value);
        }
        entries.push(`${key} = ${value}`);
      }
      return `{${entries.join(", ")}}`;
    }
    const tmp = this.fresh("o");
    const lines: string[] = [`local ${tmp} = {}`];
    const saved = this.buf;
    for (const p of node.properties) {
      if (p.type === "SpreadElement") {
        lines.push(`__rojava.object_assign(${tmp}, ${this.expr(p.argument)})`);
        continue;
      }
      let key: string;
      if (p.computed) key = `[${this.expr(p.key)}]`;
      else if (p.key.type === "Identifier") {
        key = LUAU_KEYWORDS.has(p.key.name) ? `["${p.key.name}"]` : p.key.name;
      } else key = `["${p.key.value}"]`;
      const value = p.value.type === "FunctionExpression" ? this.exprFunction(p.value) : this.expr(p.value);
      void saved;
      lines.push(`${tmp}${key.startsWith("[") ? key : `.${key}`} = ${value}`);
    }
    lines.push(`return ${tmp}`);
    return `(function()\n${lines.map((l) => "\t".repeat(this.indent + 1) + l).join("\n")}\n${"\t".repeat(this.indent)}end)()`;
  }

  private exprBinary(node: Node): string {
    const l = node.left;
    const r = node.right;
    // typeof x === "undefined" -> x == nil
    if ((node.operator === "===" || node.operator === "==" || node.operator === "!==" || node.operator === "!=")) {
      const typeofSide =
        l.type === "UnaryExpression" && l.operator === "typeof" ? l :
        r.type === "UnaryExpression" && r.operator === "typeof" ? r : null;
      const other = typeofSide === l ? r : l;
      if (typeofSide && other.type === "Literal" && other.value === "undefined") {
        const inner = this.expr(typeofSide.argument);
        return node.operator.startsWith("!") ? `(${inner} ~= nil)` : `(${inner} == nil)`;
      }
    }
    const le = this.expr(l);
    const re = this.expr(r);
    switch (node.operator) {
      case "===": case "==": return `(${le} == ${re})`;
      case "!==": case "!=": return `(${le} ~= ${re})`;
      case "+": {
        const lt = this.typeOfExpr(l);
        const rt = this.typeOfExpr(r);
        if (lt === "string" || rt === "string") {
          const L = lt === "string" ? le : `__rojava.toStr(${le})`;
          const R = rt === "string" ? re : `__rojava.toStr(${re})`;
          return `(${L} .. ${R})`;
        }
        return `(${le} + ${re})`;
      }
      case "-": return `(${le} - ${re})`;
      case "*": return `(${le} * ${re})`;
      case "/": return `(${le} / ${re})`;
      case "%": return `(${le} % ${re})`;
      case "**": return `(${le} ^ ${re})`;
      case "<": return `(${le} < ${re})`;
      case ">": return `(${le} > ${re})`;
      case "<=": return `(${le} <= ${re})`;
      case ">=": return `(${le} >= ${re})`;
      case "instanceof": return `__rojava.instanceof(${le}, ${re})`;
      case "in": return `(${re}[${le}] ~= nil)`;
      case "<<": return `bit32.lshift(${le}, ${re})`;
      case ">>": return `bit32.arshift(${le}, ${re})`;
      case ">>>": return `bit32.rshift(${le}, ${re})`;
      case "&": return `bit32.band(${le}, ${re})`;
      case "|": return `bit32.bor(${le}, ${re})`;
      case "^": return `bit32.bxor(${le}, ${re})`;
      default:
        this.diag(node, "error", `unsupported operator: ${node.operator}`);
        return "nil";
    }
  }

  private isSimpleLValue(node: Node): boolean {
    if (node.type === "Identifier") return true;
    if (node.type === "MemberExpression") {
      return !node.computed && this.isSimpleLValue(node.object) && !this.hasSideEffects(node);
    }
    return false;
  }

  private exprLogical(node: Node): string {
    const le = this.expr(node.left);
    const re = this.expr(node.right);
    if (node.operator === "&&") return `(${le} and ${re})`;
    if (node.operator === "||") return `(${le} or ${re})`;
    if (node.operator === "??") {
      if (this.isSimpleLValue(node.left)) {
        return `(if ${le} ~= nil then ${le} else ${re} end)`;
      }
      const tmp = this.fresh("nn");
      return `(function()\n${"\t".repeat(this.indent + 1)}local ${tmp} = ${le}\n${"\t".repeat(this.indent + 1)}if ${tmp} ~= nil then\n${"\t".repeat(this.indent + 2)}return ${tmp}\n${"\t".repeat(this.indent + 1)}end\n${"\t".repeat(this.indent + 1)}return ${re}\n${"\t".repeat(this.indent)}end)()`;
    }
    this.diag(node, "error", `unsupported logical operator: ${node.operator}`);
    return "nil";
  }

  private exprUnary(node: Node): string {
    const arg = this.expr(node.argument);
    switch (node.operator) {
      case "!": return `(not __rojava.bool(${arg}))`;
      case "-": return `(-${arg})`;
      case "+": return `(${arg} + 0)`;
      case "typeof": return `typeof(${arg})`;
      case "void": return "nil";
      case "delete": {
        if (node.argument.type === "MemberExpression") {
          const obj = this.memberBase(node.argument);
          const key = this.memberKey(node.argument);
          return `(function() ${obj}${key} = nil; return true end)()`;
        }
        this.diag(node, "warning", "delete is only supported on member expressions");
        return "true";
      }
      default:
        this.diag(node, "error", `unsupported unary operator: ${node.operator}`);
        return arg;
    }
  }

  private lvalueParts(node: Node): { target: string; prelude: string[] } {
    if (node.type === "Identifier") {
      return { target: this.id(node.name), prelude: [] };
    }
    if (node.type === "MemberExpression") {
      const prelude: string[] = [];
      let obj = this.expr(node.object);
      if (this.hasSideEffects(node.object)) {
        const t = this.fresh("o");
        prelude.push(`local ${t} = ${obj}`);
        obj = t;
      }
      let key: string;
      if (node.computed) {
        const objType = this.typeOfExpr(node.object);
        let idx = this.expr(node.property);
        if (this.hasSideEffects(node.property)) {
          const t = this.fresh("k");
          prelude.push(`local ${t} = ${idx}`);
          idx = t;
        }
        if (objType === "array") idx = `(${idx}) + 1`;
        key = `[${idx}]`;
      } else {
        key = `.${this.id(node.property.name)}`;
      }
      return { target: `${obj}${key}`, prelude };
    }
    this.diag(node, "error", `unsupported assignment target: ${node.type}`);
    return { target: "_", prelude: [] };
  }

  private emitUpdate(node: Node, asValue: boolean): string {
    const delta = node.operator === "++" ? "1" : "-1";
    const arg = node.argument;
    if (asValue) {
      const { target, prelude } = this.lvalueParts(arg);
      const tmp = this.fresh("u");
      const lines = [...prelude, `local ${tmp} = ${target}`, `${target} ${node.operator === "++" ? "+" : "-"}= ${delta}`];
      const ret = node.prefix ? target : tmp;
      return `(function()\n${lines.map((l) => "\t".repeat(this.indent + 1) + l).join("\n")}\n${"\t".repeat(this.indent + 1)}return ${ret}\n${"\t".repeat(this.indent)}end)()`;
    }
    const { target, prelude } = this.lvalueParts(arg);
    for (const l of prelude) this.write(l);
    this.write(`${target} ${node.operator === "++" ? "+" : "-"}= ${delta}`);
    return target;
  }

  private emitUpdateExpr(node: Node): string {
    return this.emitUpdate(node, true);
  }

  private emitAssignmentStatement(node: Node) {
    const op = node.operator;
    if (node.left.type === "ArrayPattern" || node.left.type === "ObjectPattern") {
      const tmp = this.fresh("d");
      this.write(`local ${tmp} = ${this.expr(node.right)}`);
      this.emitDestructure(node.left, tmp, false);
      return;
    }
    const { target, prelude } = this.lvalueParts(node.left);
    for (const l of prelude) this.write(l);
    const right = this.expr(node.right);
    if (op === "=") {
      if (node.left.type === "Identifier" && !this.isDeclared(node.left.name)) {
        this.diag(node, "warning", `assignment to undeclared "${node.left.name}" creates a global; declare it with let/const`);
      }
      if (node.left.type === "Identifier") {
        this.setType(node.left.name, this.typeOfExpr(node.right));
      }
      this.write(`${target} = ${right}`);
      return;
    }
    switch (op) {
      case "+=": case "-=": case "*=": case "/=": case "%=":
        this.write(`${target} ${op} ${right}`);
        return;
      case "**=":
        this.write(`${target} = ${target} ^ ${right}`);
        return;
      case "&&=":
        this.write(`${target} = ${target} and ${right}`);
        return;
      case "||=":
        this.write(`${target} = ${target} or ${right}`);
        return;
      case "??=":
        this.write(`if ${target} == nil then`);
        this.indent += 1;
        this.write(`${target} = ${right}`);
        this.indent -= 1;
        this.write("end");
        return;
      case "<<=": case ">>=": case ">>>=": case "&=": case "|=": case "^=": {
        const BIT_ASSIGN: Record<string, string> = { "<<=": "bit32.lshift", ">>=": "bit32.arshift", ">>>=": "bit32.rshift", "&=": "bit32.band", "|=": "bit32.bor", "^=": "bit32.bxor" };
        const fn = BIT_ASSIGN[op as string];
        this.write(`${target} = ${fn}(${target}, ${right})`);
        return;
      }
      default:
        this.diag(node, "error", `unsupported assignment operator: ${op}`);
        this.write(`${target} = ${right}`);
    }
  }

  private exprAssignment(node: Node): string {
    // Assignment used as a value: wrap in an IIFE.
    const tmp = this.fresh("a");
    const savedBuf = this.buf;
    const savedIndent = this.indent;
    this.buf = [];
    this.indent = 0;
    this.emitAssignmentStatement(node);
    const lines = this.buf;
    this.buf = savedBuf;
    this.indent = savedIndent;
    void tmp;
    return `(function()\n${lines.map((l) => "\t" + l).join("\n")}\n\treturn ${this.leftValueRef(node.left)}\nend)()`;
  }

  private leftValueRef(left: Node): string {
    if (left.type === "Identifier") return this.id(left.name);
    if (left.type === "MemberExpression") return `${this.expr(left.object)}${this.memberKey(left)}`;
    if (left.type === "ArrayPattern" || left.type === "ObjectPattern") return "nil";
    return "nil";
  }

  private exprConditional(node: Node): string {
    const test = this.expr(node.test);
    const cons = this.expr(node.consequent);
    const alt = this.expr(node.alternate);
    return `(if ${test} then ${cons} else ${alt} end)`;
  }

  private exprSequence(node: Node): string {
    const lines: string[] = [];
    for (let i = 0; i < node.expressions.length - 1; i += 1) {
      lines.push(this.expr(node.expressions[i]));
    }
    const last = this.expr(node.expressions[node.expressions.length - 1]);
    return `(function()\n${lines.map((l) => "\t" + l).join("\n")}\n\treturn ${last}\nend)()`;
  }

  private exprThis(node: Node): string {
    for (let i = this.fnStack.length - 1; i >= 0; i -= 1) {
      const ctx = this.fnStack[i];
      if (ctx.kind === "arrow") continue;
      if (ctx.kind === "static") return this.id(ctx.className ?? "self");
      if (ctx.kind === "method" || ctx.kind === "constructor") return "self";
      return "nil";
    }
    this.diag(node, "info", "top-level this maps to _G");
    return "_G";
  }

  private exprSuperValue(node: Node): string {
    const parent = this.superMode?.parent ?? this.classCtx?.parent;
    if (!parent) {
      this.diag(node, "error", "super used outside of a subclass");
      return "nil";
    }
    return this.id(parent);
  }

  private exprFunction(node: Node): string {
    const isArrow = node.type === "ArrowFunctionExpression";
    if (node.async) {
      this.diag(node, "error", "async functions are not supported; use task.spawn / coroutines");
    }
    if (node.generator) {
      this.diag(node, "error", "generators are not supported");
    }
    const body = this.buildFunctionBody(node.params, node.body, {
      kind: isArrow ? "arrow" : "function",
    });
    const prelude = body.prelude.map((l) => `\t${l}`).join("\n");
    const pre = prelude ? `${prelude}\n` : "";
    const inner = body.lines.map((l) => `\t${l}`).join("\n");
    const bodyText = pre + inner;
    return `function(${body.params})\n${bodyText ? bodyText + "\n" : ""}end`;
  }

  // -- member & call resolution ----------------------------------------------------

  private memberBase(node: Node): string {
    return this.expr(node.object);
  }

  private memberKey(node: Node): string {
    if (node.computed) {
      const objType = this.typeOfExpr(node.object);
      let idx = this.expr(node.property);
      if (objType === "array") {
        if (node.property.type === "Literal" && typeof node.property.value === "number") {
          return `[${node.property.value + 1}]`;
        }
        return `[(${idx}) + 1]`;
      }
      return `[${idx}]`;
    }
    return `.${this.id(node.property.name)}`;
  }

  /** Full member read, with special handling for string indexing. */
  private memberRead(node: Node): string {
    if (node.computed && this.typeOfExpr(node.object) === "string") {
      const base = this.expr(node.object);
      if (node.property.type === "Literal" && typeof node.property.value === "number") {
        const n = node.property.value;
        return `string.sub(${base}, ${n + 1}, ${n + 1})`;
      }
      const idx = this.expr(node.property);
      return `string.sub(${base}, (${idx}) + 1, (${idx}) + 1)`;
    }
    return `${this.memberBase(node)}${this.memberKey(node)}`;
  }

  private exprMember(node: Node): string {
    if (node.optional) {
      return this.optionalMember(node);
    }
    const obj = node.object;

    // console.x
    if (obj.type === "Identifier" && obj.name === "console") {
      const prop = node.property.name;
      if (prop === "log" || prop === "info" || prop === "debug" || prop === "table") return "print";
      if (prop === "warn" || prop === "error") return "warn";
      this.diag(node, "warning", `console.${prop} mapped to print`);
      return "print";
    }
    // Math constants
    if (obj.type === "Identifier" && obj.name === "Math") {
      const prop = node.property.name;
      if (prop === "PI") return "math.pi";
      if (prop === "E") return String(Math.E);
      if (prop === "LN2") return "math.log(2)";
      if (prop === "LN10") return "math.log(10)";
      if (prop === "SQRT2") return "math.sqrt(2)";
    }

    const objType = this.typeOfExpr(obj);
    if (!node.computed) {
      const prop = node.property.name;
      if ((objType === "array" || objType === "string") && prop === "length") {
        return `#${this.memberBase(node)}`;
      }
      if (objType === "map" && prop === "size") return `__rojava.map_size(${this.memberBase(node)})`;
      if (objType === "set" && prop === "size") return `__rojava.set_size(${this.memberBase(node)})`;
    }

    return this.memberRead(node);
  }

  private optionalMember(node: Node): string {
    const tmp = this.fresh("opt");
    const innerObj = this.replacements.size >= 0 ? node.object : node.object;
    const objCode = this.expr(innerObj);
    const clone = { ...node, optional: false, object: { ...node.object } };
    // Replace the base object with the temp variable reference.
    const stub = { type: "Identifier", name: tmp };
    this.replacements.set(node.object, stub as any);
    const access = this.exprMember({ ...clone, object: node.object });
    this.replacements.delete(node.object);
    return `(function()\n${"\t".repeat(this.indent + 1)}local ${tmp} = ${objCode}\n${"\t".repeat(this.indent + 1)}if ${tmp} ~= nil then\n${"\t".repeat(this.indent + 2)}return ${access}\n${"\t".repeat(this.indent + 1)}end\n${"\t".repeat(this.indent + 1)}return nil\n${"\t".repeat(this.indent)}end)()`;
  }

  private exprChain(node: Node): string {
    return this.expr(node.expression);
  }

  private exprSuperCall(node: Node, parent: string, inCtor: boolean): string {
    const args = this.emitArgList(node.arguments);
    if (inCtor) {
      return `${this.id(parent)}.new(self${args ? `, ${args}` : ""})`;
    }
    return "";
  }

  private exprCall(node: Node): string {
    const callee = node.callee;

    // super(...)
    if (callee.type === "Super") {
      const parent = this.superMode?.parent;
      if (!parent) {
        this.diag(node, "error", "super() used outside of a subclass constructor");
        return "nil";
      }
      return this.exprSuperCall(node, parent, this.superMode?.inCtor ?? false);
    }

    // optional call: obj?.m(...)
    if (node.optional && callee.type === "MemberExpression") {
      const tmp = this.fresh("opt");
      const objCode = this.expr(callee.object);
      const callCode = this.resolveMemberCall(node, tmp);
      return `(function()\n${"\t".repeat(this.indent + 1)}local ${tmp} = ${objCode}\n${"\t".repeat(this.indent + 1)}if ${tmp} == nil then\n${"\t".repeat(this.indent + 2)}return nil\n${"\t".repeat(this.indent + 1)}end\n${"\t".repeat(this.indent + 1)}return ${callCode}\n${"\t".repeat(this.indent)}end)()`;
    }

    if (callee.type === "MemberExpression") {
      // super.method(...)
      if (callee.object.type === "Super") {
        const parent = this.superMode?.parent ?? this.classCtx?.parent;
        if (!parent) {
          this.diag(node, "error", "super method call outside of a subclass");
          return "nil";
        }
        const mname = callee.computed ? `[${this.expr(callee.property)}]` : `.${this.id(callee.property.name)}`;
        const args = this.emitArgList(node.arguments);
        const selfArg = this.classCtx?.isStatic ? "" : "self";
        return `${this.id(parent)}${mname}(${selfArg}${args ? `, ${args}` : ""})`;
      }
      return this.resolveMemberCall(node);
    }

    if (callee.type === "Identifier") {
      const name = callee.name;
      const args = this.emitArgList(node.arguments);
      if (name === "String") return `tostring(${args})`;
      if (name === "Number") return `(tonumber(${args}) or 0)`;
      if (name === "Boolean") return `__rojava.bool(${args})`;
      if (name === "Array") return `{${args}}`;
      if (name === "parseInt") return `(tonumber(${args}) or (0 / 0))`;
      if (name === "parseFloat") return `(tonumber(${args}) or (0 / 0))`;
      if (name === "isNaN") return `(${args} ~= ${args})`;
      if (name === "isFinite") return `(${args} == ${args} and ${args} ~= math.huge and ${args} ~= -math.huge)`;
      return `${this.id(name)}(${args})`;
    }

    // Computed / other callees: dot call (escape hatch).
    const calleeCode = this.expr(callee);
    const args = this.emitArgList(node.arguments);
    return `${calleeCode}(${args})`;
  }

  /** Emit an argument list, handling trailing spread. */
  private emitArgList(args: Node[]): string {
    const hasSpread = args.some((a) => a.type === "SpreadElement");
    if (!hasSpread) {
      return args.map((a) => this.expr(a)).join(", ");
    }
    const wrapped = args.map((a) => {
      if (a.type === "SpreadElement") {
        return this.typeOfExpr(a.argument) === "array"
          ? this.expr(a.argument)
          : this.expr(a.argument);
      }
      return `{${this.expr(a)}}`;
    });
    return `table.unpack(__rojava.array_concat(${wrapped.join(", ")}))`;
  }

  private resolveMemberCall(node: Node, baseOverride?: string): string {
    const callee = node.callee;
    const obj = callee.object;
    const args = this.emitArgList(node.arguments);

    // Identifier roots with special tables.
    if (obj.type === "Identifier") {
      const root = obj.name;
      if (root === "Math" && !callee.computed) {
        const prop = callee.property.name;
        if (prop === "pow" && node.arguments.length === 2) {
          const a = this.expr(node.arguments[0]);
          const b = this.expr(node.arguments[1]);
          return `(${a} ^ ${b})`;
        }
        if (prop === "round") return `math.floor(${args} + 0.5)`;
        if (prop === "trunc") return `(if ${args} >= 0 then math.floor(${args}) else math.ceil(${args}) end)`;
        if (prop === "sign") return `(if ${args} > 0 then 1 elseif ${args} < 0 then -1 else 0 end)`;
        if (prop === "hypot" && node.arguments.length === 2) {
          const a = this.expr(node.arguments[0]);
          const b = this.expr(node.arguments[1]);
          return `math.sqrt(${a} * ${a} + ${b} * ${b})`;
        }
        if (MATH_MAP[prop]) return `${MATH_MAP[prop]}(${args})`;
        this.diag(callee, "warning", `Math.${prop} is not supported; emitting math.${prop}`);
        return `math.${prop}(${args})`;
      }
      if (root === "JSON" && !callee.computed) {
        const prop = callee.property.name;
        if (prop === "stringify") return `__rojava.json_stringify(${this.expr(node.arguments[0])})`;
        if (prop === "parse") return `__rojava.json_parse(${args})`;
      }
      if (root === "Object" && !callee.computed) {
        const prop = callee.property.name;
        if (prop === "keys") return `__rojava.object_keys(${args})`;
        if (prop === "values") return `__rojava.object_values(${args})`;
        if (prop === "entries") return `__rojava.object_entries(${args})`;
        if (prop === "assign") return `__rojava.object_assign(${args})`;
        if (prop === "fromEntries") return `__rojava.object_fromEntries(${args})`;
        if (prop === "freeze") return `__rojava.object_freeze(${args})`;
      }
      if (root === "Array" && !callee.computed) {
        const prop = callee.property.name;
        if (prop === "isArray") return `__rojava.array_isArray(${args})`;
        if (prop === "of") return `{${args}}`;
        if (prop === "from") {
          const t = this.typeOfExpr(node.arguments[0]);
          if (t === "array") return `__rojava.array_slice(${args}, 0)`;
          if (t === "string") return `__rojava.str_split(${args}, "")`;
          return `__rojava.array_slice(${args}, 0)`;
        }
      }
      if (root === "Instance" && !callee.computed && callee.property.name === "new") {
        return `Instance.new(${args})`;
      }
      if (root === "console") {
        const prop = callee.property.name;
        const fn = prop === "warn" || prop === "error" ? "warn" : "print";
        return `${fn}(${args})`;
      }
    }

    const base = baseOverride ?? this.memberBase(callee);
    const objType = this.typeOfExpr(obj);

    // String methods
    if (objType === "string" && !callee.computed) {
      const prop = callee.property.name;
      if (prop === "toUpperCase") return `string.upper(${base})`;
      if (prop === "toLowerCase") return `string.lower(${base})`;
      if (prop === "repeat") return `string.rep(${base}, ${args})`;
      if (prop === "concat") return `(${base} .. ${args.split(", ").join(" .. ")})`;
      if (prop === "at" || prop === "charAt") return `__rojava.str_charAt(${base}, ${args})`;
      if (STRING_METHODS[prop]) return `__rojava.${STRING_METHODS[prop]}(${base}${args ? `, ${args}` : ""})`;
      this.diag(callee, "warning", `string method ${prop} is not supported; emitting dynamic invoke`);
      return `__rojava.invoke(${base}, "${prop}"${args ? `, ${args}` : ""})`;
    }

    // Array methods
    if (objType === "array" && !callee.computed) {
      const prop = callee.property.name;
      if (prop === "concat") return `__rojava.array_concat(${base}${args ? `, ${args}` : ""})`;
      if (prop === "toString") return `__rojava.array_join(${base})`;
      if (ARRAY_METHODS[prop]) return `__rojava.${ARRAY_METHODS[prop]}(${base}${args ? `, ${args}` : ""})`;
      this.diag(callee, "warning", `array method ${prop} is not supported; emitting dynamic invoke`);
      return `__rojava.invoke(${base}, "${prop}"${args ? `, ${args}` : ""})`;
    }

    // Map / Set methods
    if ((objType === "map" || objType === "set") && !callee.computed) {
      return `${base}:${this.id(callee.property.name)}(${args})`;
    }

    // Roblox instance / class method -> colon call.
    if ((objType === "instance" || objType.startsWith("class:")) && !callee.computed) {
      return `${base}:${this.id(callee.property.name)}(${args})`;
    }

    // Library / module roots and known dot roots -> dot call.
    if ((objType === "library" || objType === "module" || objType === "global") && !callee.computed) {
      return `${base}.${this.id(callee.property.name)}(${args})`;
    }
    if (obj.type === "Identifier" && (DOT_ROOTS.has(obj.name) || ROBLOX_GLOBALS.has(obj.name))) {
      return `${base}.${this.id(callee.property.name)}(${args})`;
    }

    // Computed callee -> dot-style escape hatch.
    if (callee.computed) {
      return `${base}[${this.expr(callee.property)}](${args})`;
    }

    // Unknown receiver: dynamic invoke passing self.
    return `__rojava.invoke(${base}, "${callee.property.name}"${args ? `, ${args}` : ""})`;
  }

  private exprNew(node: Node): string {
    const callee = node.callee;
    const args = this.emitArgList(node.arguments);
    if (callee.type === "Identifier") {
      const name = callee.name;
      if (name === "Map") return `__rojava.Map.new(${args})`;
      if (name === "Set") return `__rojava.Set.new(${args})`;
      if (name === "Array") {
        if (node.arguments.length === 0) return "{}";
        return `table.create(${args})`;
      }
      if (name === "Error" || name === "TypeError" || name === "RangeError") {
        const msg = node.arguments[0] ? this.expr(node.arguments[0]) : '""';
        return `{ message = ${msg}, name = "${name}" }`;
      }
      if (DATATYPES.has(name)) return `${name}.new(${args})`;
      if (this.classNames.has(name)) return `${this.id(name)}.new(nil${args ? `, ${args}` : ""})`;
      if (ROBLOX_GLOBALS.has(name)) return `${name}.new(${args})`;
      return `${this.id(name)}.new(${args})`;
    }
    if (callee.type === "MemberExpression") {
      return `${this.expr(callee)}.new(${args})`;
    }
    this.diag(node, "error", "unsupported new target");
    return `nil`;
  }

  // -- type inference -------------------------------------------------------------

  typeOfExpr(node: Node): string {
    if (!node) return "unknown";
    switch (node.type) {
      case "Identifier": return this.lookupType(node.name);
      case "Literal":
        if (typeof node.value === "string") return "string";
        if (typeof node.value === "number") return "number";
        if (typeof node.value === "boolean") return "boolean";
        return "unknown";
      case "TemplateLiteral": return "string";
      case "ArrayExpression": return "array";
      case "ObjectExpression": return "table";
      case "FunctionExpression":
      case "ArrowFunctionExpression": return "function";
      case "NewExpression": {
        const c = node.callee;
        if (c.type === "Identifier") {
          if (c.name === "Map") return "map";
          if (c.name === "Set") return "set";
          if (DATATYPES.has(c.name)) return "datatype";
          if (this.classNames.has(c.name)) return `class:${c.name}`;
          if (ROBLOX_GLOBALS.has(c.name)) return "instance";
        }
        return "unknown";
      }
      case "MemberExpression": {
        if (node.object.type === "Identifier" && COLON_ROOTS.has(node.object.name)) return "instance";
        const ot = this.typeOfExpr(node.object);
        if (!node.computed) {
          const prop = node.property.name;
          if ((ot === "array" || ot === "string") && prop === "length") return "number";
          if ((ot === "map" || ot === "set") && prop === "size") return "number";
        }
        if (ot === "instance" && !node.computed && node.property.name === "Parent") return "instance";
        return "unknown";
      }
      case "CallExpression": {
        const callee = node.callee;
        if (callee.type === "Identifier") {
          if (callee.name === "require") return "module";
          if (callee.name === "String") return "string";
          if (callee.name === "Number") return "number";
          if (callee.name === "Array") return "array";
          return "unknown";
        }
        if (callee.type === "MemberExpression" && !callee.computed) {
          const prop = callee.property.name;
          if (callee.object.type === "Identifier") {
            const root = callee.object.name;
            if (root === "Instance" && prop === "new") return "instance";
            if (root === "JSON" && prop === "stringify") return "string";
            if (root === "Array") return "array";
            if (root === "console") return "unknown";
            if (COLON_ROOTS.has(root) && INSTANCE_RETURNING.has(prop)) return "instance";
          }
          const objType = this.typeOfExpr(callee.object);
          if (objType === "instance" && INSTANCE_RETURNING.has(prop)) return "instance";
          if (objType === "instance" && INSTANCE_ARRAY_RETURNING.has(prop)) return "array";
          if (objType === "array" && ARRAY_RETURNS_ARRAY.has(prop)) return "array";
          if (objType === "string") {
            if (prop === "split") return "array";
            if (STRING_RETURNS_STRING.has(prop)) return "string";
          }
          if (objType.startsWith("class:") && prop === "new") return objType;
        }
        return "unknown";
      }
      case "ConditionalExpression": {
        const a = this.typeOfExpr(node.consequent);
        const b = this.typeOfExpr(node.alternate);
        return a === b ? a : "unknown";
      }
      case "LogicalExpression":
        return this.typeOfExpr(node.right);
      case "BinaryExpression": {
        const a = this.typeOfExpr(node.left);
        const b = this.typeOfExpr(node.right);
        if (["==", "===", "!=", "!==", "<", ">", "<=", ">=", "in", "instanceof"].includes(node.operator)) return "boolean";
        if (node.operator === "+" && (a === "string" || b === "string")) return "string";
        if (["+", "-", "*", "/", "%", "**", "<<", ">>", ">>>", "&", "|", "^"].includes(node.operator)) return "number";
        return "unknown";
      }
      case "AssignmentExpression": return this.typeOfExpr(node.right);
      case "SequenceExpression":
        return this.typeOfExpr(node.expressions[node.expressions.length - 1]);
      case "ThisExpression": return "unknown";
      case "ChainExpression": return this.typeOfExpr(node.expression);
      default: return "unknown";
    }
  }
}

/** Compile a single JS source string to Luau. */
export function emitLuau(source: string, fileName = "main.js"): { code: string; diagnostics: Diagnostic[] } {
  const emitter = new Emitter({ fileName });
  const code = emitter.emitProgram(source);
  return { code, diagnostics: emitter.diagnostics };
}
