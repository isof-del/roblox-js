export type DiagnosticSeverity = "error" | "warning" | "info";

export interface Diagnostic {
  severity: DiagnosticSeverity;
  message: string;
  line: number;
  column: number;
  file?: string;
}

export interface OutputFile {
  /** Output path, e.g. "src/main.luau" or "_rojava.luau" */
  path: string;
  content: string;
  kind: "source" | "runtime" | "config";
}

export interface CompileOptions {
  /** Name used in the Rojo project file and headers. */
  projectName?: string;
  /** Emit the shared runtime module into the output set. */
  includeRuntime?: boolean;
  /** Target script kind, cosmetic header only. */
  target?: "script" | "module";
  /** Version stamp written into headers. */
  version?: string;
}

export interface CompileStats {
  statements: number;
  expressions: number;
  locals: number;
}

export interface CompileResult {
  outputs: OutputFile[];
  diagnostics: Diagnostic[];
  timeMs: number;
  stats: CompileStats;
}

export interface SourceFile {
  name: string; // e.g. "main.js" or "src/util.js"
  content: string;
}

export const RJ_VERSION = "1.0.0";
