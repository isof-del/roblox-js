import { RJ_VERSION } from "./types";

/**
 * The roblox-java runtime library, emitted as `_rojava.luau` in every build.
 * Mirrors the role of the roblox-ts runtime: it implements JavaScript
 * standard-library semantics on top of Luau tables.
 *
 * NOTE: String.raw is used so the Luau source is emitted byte-for-byte.
 */
export const RUNTIME_FILE_NAME = "_rojava.luau";

const RAW_RUNTIME = String.raw`--[[
	roblox-java runtime v__VERSION__
	JavaScript standard-library semantics for compiled Luau output.
	Injected automatically by the compiler. Do not edit by hand.
]]

local Rojava = {}

-- ---------------------------------------------------------------------------
-- coercion
-- ---------------------------------------------------------------------------

function Rojava.toStr(v)
	if v == nil then
		return "nil"
	elseif type(v) == "table" then
		local mt = getmetatable(v)
		if mt == Rojava.Map or mt == Rojava.Set then
			return tostring(v)
		end
		local parts = {}
		for i = 1, #v do
			parts[i] = Rojava.toStr(v[i])
		end
		return table.concat(parts, ",")
	else
		return tostring(v)
	end
end

function Rojava.bool(v)
	if v == nil or v == false or v == 0 or v == "" then
		return false
	end
	if type(v) == "number" and v ~= v then
		return false -- NaN
	end
	return true
end

-- ---------------------------------------------------------------------------
-- Array (arrays compile to 1-based contiguous tables)
-- ---------------------------------------------------------------------------

function Rojava.array_push(t, ...)
	local n = select("#", ...)
	for i = 1, n do
		t[#t + 1] = select(i, ...)
	end
	return #t
end

function Rojava.array_pop(t)
	local n = #t
	if n == 0 then
		return nil
	end
	local v = t[n]
	t[n] = nil
	return v
end

function Rojava.array_shift(t)
	local n = #t
	if n == 0 then
		return nil
	end
	local v = t[1]
	table.remove(t, 1)
	return v
end

function Rojava.array_unshift(t, ...)
	local n = select("#", ...)
	for i = n, 1, -1 do
		table.insert(t, 1, select(i, ...))
	end
	return #t
end

function Rojava.array_indexOf(t, value, from)
	local n = #t
	local start = (from or 0) + 1
	if start < 1 then
		start = math.max(n + start, 1)
	end
	for i = start, n do
		if t[i] == value then
			return i - 1
		end
	end
	return -1
end

function Rojava.array_lastIndexOf(t, value, from)
	local n = #t
	local start = if from == nil then n else math.min(from, n - 1) + 1
	for i = start, 1, -1 do
		if t[i] == value then
			return i - 1
		end
	end
	return -1
end

function Rojava.array_includes(t, value, from)
	return Rojava.array_indexOf(t, value, from) ~= -1
end

function Rojava.array_join(t, sep)
	local parts = {}
	for i = 1, #t do
		parts[i] = Rojava.toStr(t[i])
	end
	return table.concat(parts, sep or ",")
end

function Rojava.array_slice(t, start, stop)
	local n = #t
	local s = start or 0
	local e = if stop == nil then n else stop
	if s < 0 then
		s = math.max(n + s, 0)
	end
	if e < 0 then
		e = n + e
	end
	e = math.min(e, n)
	local out = {}
	for i = s + 1, e do
		out[#out + 1] = t[i]
	end
	return out
end

function Rojava.array_splice(t, start, deleteCount, ...)
	local n = #t
	local s = start or 0
	if s < 0 then
		s = math.max(n + s, 0)
	end
	s = math.min(s, n)
	local count = if deleteCount == nil then n - s else math.max(0, deleteCount)
	local removed = {}
	for _ = 1, count do
		removed[#removed + 1] = t[s + 1]
		table.remove(t, s + 1)
	end
	local inserts = table.pack(...)
	for i = inserts.n, 1, -1 do
		table.insert(t, s + 1, inserts[i])
	end
	return removed
end

function Rojava.array_concat(...)
	local out = {}
	local n = select("#", ...)
	for i = 1, n do
		local v = select(i, ...)
		if type(v) == "table" and getmetatable(v) == nil then
			for j = 1, #v do
				out[#out + 1] = v[j]
			end
		else
			out[#out + 1] = v
		end
	end
	return out
end

function Rojava.array_reverse(t)
	local i, j = 1, #t
	while i < j do
		t[i], t[j] = t[j], t[i]
		i += 1
		j -= 1
	end
	return t
end

function Rojava.array_sort(t, cmp)
	if cmp == nil then
		table.sort(t, function(a, b)
			return tostring(a) < tostring(b)
		end)
	else
		table.sort(t, function(a, b)
			return cmp(a, b) < 0
		end)
	end
	return t
end

function Rojava.array_map(t, fn)
	local out = {}
	for i = 1, #t do
		out[i] = fn(t[i], i - 1)
	end
	return out
end

function Rojava.array_filter(t, fn)
	local out = {}
	for i = 1, #t do
		if Rojava.bool(fn(t[i], i - 1)) then
			out[#out + 1] = t[i]
		end
	end
	return out
end

function Rojava.array_reduce(t, fn, init)
	local acc = init
	local start = 1
	if acc == nil then
		acc = t[1]
		start = 2
	end
	for i = start, #t do
		acc = fn(acc, t[i], i - 1)
	end
	return acc
end

function Rojava.array_reduceRight(t, fn, init)
	local acc = init
	local start = #t
	if acc == nil then
		acc = t[start]
		start = start - 1
	end
	for i = start, 1, -1 do
		acc = fn(acc, t[i], i - 1)
	end
	return acc
end

function Rojava.array_forEach(t, fn)
	for i = 1, #t do
		fn(t[i], i - 1)
	end
end

function Rojava.array_find(t, fn)
	for i = 1, #t do
		if Rojava.bool(fn(t[i], i - 1)) then
			return t[i]
		end
	end
	return nil
end

function Rojava.array_findIndex(t, fn)
	for i = 1, #t do
		if Rojava.bool(fn(t[i], i - 1)) then
			return i - 1
		end
	end
	return -1
end

function Rojava.array_some(t, fn)
	for i = 1, #t do
		if Rojava.bool(fn(t[i], i - 1)) then
			return true
		end
	end
	return false
end

function Rojava.array_every(t, fn)
	for i = 1, #t do
		if not Rojava.bool(fn(t[i], i - 1)) then
			return false
		end
	end
	return true
end

function Rojava.array_flat(t, depth)
	local d = if depth == nil then 1 else depth
	local out = {}
	local function walk(list, level)
		for i = 1, #list do
			local v = list[i]
			if level < d and type(v) == "table" and getmetatable(v) == nil then
				walk(v, level + 1)
			else
				out[#out + 1] = v
			end
		end
	end
	walk(t, 0)
	return out
end

function Rojava.array_fill(t, value, start, stop)
	local n = #t
	local s = (start or 0) + 1
	local e = if stop == nil then n else stop
	for i = s, e do
		t[i] = value
	end
	return t
end

function Rojava.array_isArray(v)
	return type(v) == "table" and getmetatable(v) == nil
end

-- ---------------------------------------------------------------------------
-- String
-- ---------------------------------------------------------------------------

function Rojava.str_indexOf(s, needle, from)
	local start = (from or 0) + 1
	if needle == "" then
		return math.min(start - 1, #s)
	end
	local p = string.find(s, needle, start, true)
	if p == nil then
		return -1
	end
	return p - 1
end

function Rojava.str_lastIndexOf(s, needle)
	local best = -1
	local from = 1
	while true do
		local p = string.find(s, needle, from, true)
		if p == nil then
			break
		end
		best = p - 1
		from = p + 1
	end
	return best
end

function Rojava.str_includes(s, needle, from)
	return Rojava.str_indexOf(s, needle, from) ~= -1
end

function Rojava.str_startsWith(s, prefix)
	return string.sub(s, 1, #prefix) == prefix
end

function Rojava.str_endsWith(s, suffix)
	return string.sub(s, #s - #suffix + 1) == suffix
end

function Rojava.str_padStart(s, len, pad)
	local p = if pad == nil or pad == "" then " " else pad
	while #s < len do
		s = string.sub(p, 1, len - #s) .. s
	end
	return s
end

function Rojava.str_padEnd(s, len, pad)
	local p = if pad == nil or pad == "" then " " else pad
	while #s < len do
		s = s .. string.sub(p, 1, len - #s)
	end
	return s
end

function Rojava.str_trim(s)
	return (string.gsub(string.gsub(s, "^%s+", ""), "%s+$", ""))
end

function Rojava.str_trimStart(s)
	return (string.gsub(s, "^%s+", ""))
end

function Rojava.str_trimEnd(s)
	return (string.gsub(s, "%s+$", ""))
end

function Rojava.str_split(s, sep, limit)
	local out = {}
	if sep == "" then
		for i = 1, #s do
			out[#out + 1] = string.sub(s, i, i)
		end
	else
		local from = 1
		while true do
			local p = string.find(s, sep, from, true)
			if p == nil then
				out[#out + 1] = string.sub(s, from)
				break
			end
			out[#out + 1] = string.sub(s, from, p - 1)
			from = p + #sep
		end
	end
	if limit ~= nil then
		while #out > limit do
			out[#out] = nil
		end
	end
	return out
end

function Rojava.str_slice(s, start, stop)
	local n = #s
	local a = start or 0
	local b = if stop == nil then n else stop
	if a < 0 then
		a = math.max(n + a, 0)
	end
	if b < 0 then
		b = n + b
	end
	a = math.min(math.max(a, 0), n)
	b = math.min(math.max(b, 0), n)
	if b <= a then
		return ""
	end
	return string.sub(s, a + 1, b)
end

function Rojava.str_substring(s, start, stop)
	local a = start or 0
	local b = if stop == nil then #s else stop
	if a < 0 then
		a = 0
	end
	if b < 0 then
		b = 0
	end
	if a > b then
		a, b = b, a
	end
	return string.sub(s, a + 1, b)
end

function Rojava.str_charAt(s, i)
	if i < 0 or i >= #s then
		return ""
	end
	return string.sub(s, i + 1, i + 1)
end

function Rojava.str_charCodeAt(s, i)
	local b = string.byte(s, i + 1)
	if b == nil then
		return 0 / 0
	end
	return b
end

function Rojava.str_replace(s, pattern, replacement)
	local p = string.find(s, pattern, 1, true)
	if p == nil then
		return s
	end
	local rep
	if type(replacement) == "function" then
		rep = Rojava.toStr(replacement(string.sub(s, p, p + #pattern - 1), p - 1))
	else
		rep = Rojava.toStr(replacement)
	end
	return string.sub(s, 1, p - 1) .. rep .. string.sub(s, p + #pattern)
end

function Rojava.str_replaceAll(s, pattern, replacement)
	if pattern == "" then
		return s
	end
	local out = {}
	local from = 1
	while true do
		local p = string.find(s, pattern, from, true)
		if p == nil then
			out[#out + 1] = string.sub(s, from)
			break
		end
		out[#out + 1] = string.sub(s, from, p - 1)
		if type(replacement) == "function" then
			out[#out + 1] = Rojava.toStr(replacement(pattern, p - 1))
		else
			out[#out + 1] = Rojava.toStr(replacement)
		end
		from = p + #pattern
	end
	return table.concat(out)
end

-- ---------------------------------------------------------------------------
-- Object
-- ---------------------------------------------------------------------------

function Rojava.object_keys(t)
	local out = {}
	for k in pairs(t) do
		out[#out + 1] = k
	end
	return out
end

function Rojava.object_values(t)
	local out = {}
	for _, v in pairs(t) do
		out[#out + 1] = v
	end
	return out
end

function Rojava.object_entries(t)
	local out = {}
	for k, v in pairs(t) do
		out[#out + 1] = { k, v }
	end
	return out
end

function Rojava.object_assign(target, ...)
	local n = select("#", ...)
	for i = 1, n do
		local src = select(i, ...)
		if src ~= nil then
			for k, v in pairs(src) do
				target[k] = v
			end
		end
	end
	return target
end

function Rojava.object_fromEntries(entries)
	local out = {}
	for i = 1, #entries do
		out[entries[i][1]] = entries[i][2]
	end
	return out
end

function Rojava.object_freeze(t)
	return t
end

-- ---------------------------------------------------------------------------
-- Map / Set
-- ---------------------------------------------------------------------------

Rojava.Map = {}
Rojava.Map.__index = Rojava.Map

function Rojava.Map.new(entries)
	local self = setmetatable({ __data = {}, __size = 0 }, Rojava.Map)
	if entries ~= nil then
		for i = 1, #entries do
			self:set(entries[i][1], entries[i][2])
		end
	end
	return self
end

function Rojava.Map:set(k, v)
	if self.__data[k] == nil then
		self.__size += 1
	end
	self.__data[k] = v
	return self
end

function Rojava.Map:get(k)
	return self.__data[k]
end

function Rojava.Map:has(k)
	return self.__data[k] ~= nil
end

function Rojava.Map:delete(k)
	if self.__data[k] ~= nil then
		self.__data[k] = nil
		self.__size -= 1
		return true
	end
	return false
end

function Rojava.Map:clear()
	self.__data = {}
	self.__size = 0
end

function Rojava.Map:forEach(fn)
	for k, v in pairs(self.__data) do
		fn(v, k, self)
	end
end

function Rojava.Map:keys()
	return Rojava.object_keys(self.__data)
end

function Rojava.Map:values()
	return Rojava.object_values(self.__data)
end

function Rojava.Map:entries()
	return Rojava.object_entries(self.__data)
end

function Rojava.map_size(m)
	return m.__size
end

Rojava.Set = {}
Rojava.Set.__index = Rojava.Set

function Rojava.Set.new(values)
	local self = setmetatable({ __data = {}, __size = 0 }, Rojava.Set)
	if values ~= nil then
		for i = 1, #values do
			self:add(values[i])
		end
	end
	return self
end

function Rojava.Set:add(v)
	if self.__data[v] == nil then
		self.__size += 1
	end
	self.__data[v] = true
	return self
end

function Rojava.Set:has(v)
	return self.__data[v] ~= nil
end

function Rojava.Set:delete(v)
	if self.__data[v] ~= nil then
		self.__data[v] = nil
		self.__size -= 1
		return true
	end
	return false
end

function Rojava.Set:clear()
	self.__data = {}
	self.__size = 0
end

function Rojava.Set:forEach(fn)
	for v in pairs(self.__data) do
		fn(v, v, self)
	end
end

function Rojava.Set:values()
	return Rojava.object_keys(self.__data)
end

function Rojava.set_size(s)
	return s.__size
end

-- ---------------------------------------------------------------------------
-- iteration & dynamic access
-- ---------------------------------------------------------------------------

function Rojava.iter(x)
	if type(x) == "string" then
		local i = 0
		return function()
			i += 1
			if i > #x then
				return nil
			end
			return i, string.sub(x, i, i)
		end
	end
	local mt = getmetatable(x)
	if mt == Rojava.Map then
		local keys = Rojava.object_keys(x.__data)
		local i = 0
		return function()
			i += 1
			local k = keys[i]
			if k == nil then
				return nil
			end
			return i, { k, x.__data[k] }
		end
	end
	if mt == Rojava.Set then
		local vals = Rojava.object_keys(x.__data)
		local i = 0
		return function()
			i += 1
			local v = vals[i]
			if v == nil then
				return nil
			end
			return i, v
		end
	end
	return ipairs(x)
end

function Rojava.get(obj, key)
	if obj == nil then
		return nil
	end
	if key == "length" then
		if type(obj) == "string" then
			return #obj
		elseif type(obj) == "table" then
			local mt = getmetatable(obj)
			if mt == Rojava.Map then
				return obj.__size
			elseif mt == Rojava.Set then
				return obj.__size
			end
			return #obj
		end
	end
	return obj[key]
end

function Rojava.invoke(obj, name, ...)
	if type(obj) == "table" then
		local fn = obj[name]
		if type(fn) == "function" then
			return fn(obj, ...)
		end
		-- Fall back to the JavaScript standard library shims so that
		-- dynamically-typed values still behave like arrays / strings.
		local arr = Rojava["array_" .. name]
		if type(arr) == "function" then
			return arr(obj, ...)
		end
	elseif type(obj) == "string" then
		local str = Rojava["str_" .. name]
		if type(str) == "function" then
			return str(obj, ...)
		end
		if name == "length" then
			return #obj
		end
	end
	local fn = obj[name]
	if type(fn) ~= "function" then
		error("attempt to call missing method '" .. name .. "'", 0)
	end
	return fn(obj, ...)
end

function Rojava.instanceof(obj, class)
	if type(obj) ~= "table" then
		return false
	end
	local mt = getmetatable(obj)
	while mt ~= nil do
		if mt == class then
			return true
		end
		mt = getmetatable(mt)
	end
	return false
end

-- ---------------------------------------------------------------------------
-- JSON
-- ---------------------------------------------------------------------------

local function json_stringify_value(value, seen)
	local tv = type(value)
	if value == nil then
		return "null"
	elseif tv == "boolean" then
		return tostring(value)
	elseif tv == "number" then
		if value ~= value or value == math.huge or value == -math.huge then
			return "null"
		end
		return string.format("%.14g", value)
	elseif tv == "string" then
		local escaped = string.gsub(value, "[%z\"%c]", function(c)
			if c == "\\" then
				return "\\\\"
			elseif c == "\"" then
				return "\\\""
			elseif c == "\n" then
				return "\\n"
			elseif c == "\t" then
				return "\\t"
			elseif c == "\r" then
				return "\\r"
			else
				return string.format("\\u%04x", string.byte(c))
			end
		end)
		return "\"" .. escaped .. "\""
	elseif tv == "table" then
		if seen[value] then
			error("JSON.stringify: cyclic value", 0)
		end
		seen[value] = true
		local isArray = #value > 0 or next(value) == nil
		if isArray then
			local parts = {}
			for i = 1, #value do
				parts[i] = json_stringify_value(value[i], seen)
			end
			seen[value] = nil
			return "[" .. table.concat(parts, ",") .. "]"
		else
			local parts = {}
			for k, v in pairs(value) do
				if type(k) == "string" or type(k) == "number" then
					parts[#parts + 1] = json_stringify_value(tostring(k), seen) .. ":" .. json_stringify_value(v, seen)
				end
			end
			table.sort(parts)
			seen[value] = nil
			return "{" .. table.concat(parts, ",") .. "}"
		end
	end
	return "null"
end

function Rojava.json_stringify(value)
	return json_stringify_value(value, {})
end

function Rojava.json_parse(src)
	local pos = 1

	local function skip_ws()
		while true do
			local c = string.sub(src, pos, pos)
			if c == " " or c == "\t" or c == "\r" or c == "\n" then
				pos += 1
			else
				break
			end
		end
	end

	local parse_value

	local function parse_string()
		local out = {}
		pos += 1 -- opening quote
		while true do
			local c = string.sub(src, pos, pos)
			if c == "\"" then
				pos += 1
				return table.concat(out)
			elseif c == "\\" then
				local esc = string.sub(src, pos + 1, pos + 1)
				pos += 2
				if esc == "n" then
					out[#out + 1] = "\n"
				elseif esc == "t" then
					out[#out + 1] = "\t"
				elseif esc == "r" then
					out[#out + 1] = "\r"
				elseif esc == "b" then
					out[#out + 1] = "\8"
				elseif esc == "f" then
					out[#out + 1] = "\12"
				elseif esc == "\"" then
					out[#out + 1] = "\""
				elseif esc == "\\" then
					out[#out + 1] = "\\"
				elseif esc == "/" then
					out[#out + 1] = "/"
				elseif esc == "u" then
					local hex = string.sub(src, pos, pos + 3)
					out[#out + 1] = string.char(tonumber(hex, 16) or 63)
					pos += 4
				end
			else
				out[#out + 1] = c
				pos += 1
			end
		end
	end

	local function parse_number()
		local s, e = string.find(src, "^-?%d+%.?%d*[eE]?[+-]?%d*", pos)
		local num = tonumber(string.sub(src, s, e))
		pos = e + 1
		return num
	end

	local function parse_object()
		pos += 1
		local out = {}
		skip_ws()
		if string.sub(src, pos, pos) == "}" then
			pos += 1
			return out
		end
		while true do
			skip_ws()
			local key = parse_string()
			skip_ws()
			pos += 1 -- colon
			skip_ws()
			out[key] = parse_value()
			skip_ws()
			local c = string.sub(src, pos, pos)
			pos += 1
			if c == "}" then
				return out
			end
		end
	end

	local function parse_array()
		pos += 1
		local out = {}
		skip_ws()
		if string.sub(src, pos, pos) == "]" then
			pos += 1
			return out
		end
		while true do
			skip_ws()
			out[#out + 1] = parse_value()
			skip_ws()
			local c = string.sub(src, pos, pos)
			pos += 1
			if c == "]" then
				return out
			end
		end
	end

	parse_value = function()
		local c = string.sub(src, pos, pos)
		if c == "{" then
			return parse_object()
		elseif c == "[" then
			return parse_array()
		elseif c == "\"" then
			return parse_string()
		elseif string.sub(src, pos, pos + 3) == "true" then
			pos += 4
			return true
		elseif string.sub(src, pos, pos + 4) == "false" then
			pos += 5
			return false
		elseif string.sub(src, pos, pos + 3) == "null" then
			pos += 4
			return nil
		else
			return parse_number()
		end
	end

	skip_ws()
	return parse_value()
end

return Rojava
`;

export const RUNTIME_SOURCE = RAW_RUNTIME.replace("__VERSION__", RJ_VERSION);
