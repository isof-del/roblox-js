import { ReactNode } from "react";

type Lang = "js" | "lua" | "json" | "bash";

const JS_KEYWORDS = new Set(
  "const let var function return if else for while do switch case default break continue new class extends super this typeof instanceof in of try catch finally throw import export from as async await yield null undefined true false delete void static get set".split(" "),
);

const LUA_KEYWORDS = new Set(
  "local function end if then else elseif for while do repeat until return break continue in nil true false and or not self goto".split(" "),
);

const ROBLOX_NAMES = new Set(
  "print warn game workspace script task Instance Enum Vector3 Vector2 Color3 UDim2 CFrame math string table os pairs ipairs require pcall xpcall error tostring tonumber select setmetatable getmetatable".split(" "),
);

interface Tok {
  t: string;
  c?: string; // tailwind text color class
}

function tokenize(code: string, lang: Lang): Tok[] {
  const toks: Tok[] = [];
  let i = 0;
  const n = code.length;
  const isJson = lang === "json";

  const push = (t: string, c?: string) => {
    if (t) toks.push({ t, c });
  };

  while (i < n) {
    const rest = code.slice(i);

    // comments
    if (lang === "lua" && rest.startsWith("--")) {
      const nl = rest.indexOf("\n");
      const end = nl === -1 ? n : i + nl;
      push(code.slice(i, end), "text-dim italic");
      i = end;
      continue;
    }
    if (lang === "js" && rest.startsWith("//")) {
      const nl = rest.indexOf("\n");
      const end = nl === -1 ? n : i + nl;
      push(code.slice(i, end), "text-dim italic");
      i = end;
      continue;
    }
    if (lang === "js" && rest.startsWith("/*")) {
      const end = code.indexOf("*/", i + 2);
      const stop = end === -1 ? n : end + 2;
      push(code.slice(i, stop), "text-dim italic");
      i = stop;
      continue;
    }

    // strings
    const ch = code[i];
    if (ch === '"' || ch === "'" || ch === "`") {
      let j = i + 1;
      while (j < n) {
        if (code[j] === "\\") {
          j += 2;
          continue;
        }
        if (code[j] === ch) break;
        if (ch !== "`" && code[j] === "\n") break;
        j += 1;
      }
      push(code.slice(i, Math.min(j + 1, n)), "text-mint");
      i = j + 1;
      continue;
    }

    // numbers
    const numMatch = /^[\d][\w.]*/.exec(rest);
    if (numMatch && !/^[\w]/.test(code[i - 1] ?? "")) {
      if (/^\d/.test(ch) || (ch === "." && /^\d/.test(rest.slice(1)))) {
        push(numMatch[0], "text-sky");
        i += numMatch[0].length;
        continue;
      }
    }

    // words
    const word = /^[A-Za-z_][\w]*/.exec(rest);
    if (word) {
      const w = word[0];
      const kw = lang === "lua" ? LUA_KEYWORDS : JS_KEYWORDS;
      let cls: string | undefined;
      if (isJson) {
        cls = code[i + w.length] === ":" ? "text-sky" : undefined;
      } else if (kw.has(w)) cls = "text-amber";
      else if (ROBLOX_NAMES.has(w)) cls = "text-ember";
      else if (code[i + w.length] === "(") cls = "text-ink";
      push(w, cls);
      i += w.length;
      continue;
    }

    // operators / punctuation
    const op = /^[+\-*/%=<>!&|^~?:.,;(){}[\]]+/.exec(rest);
    if (op) {
      push(op[0], "text-mut");
      i += op[0].length;
      continue;
    }

    push(ch);
    i += 1;
  }
  return toks;
}

export function HighlightedCode({ code, lang }: { code: string; lang: Lang }) {
  const toks = tokenize(code.trimEnd(), lang);
  const out: ReactNode[] = [];
  toks.forEach((tok, idx) => {
    out.push(
      tok.c ? (
        <span key={idx} className={tok.c}>
          {tok.t}
        </span>
      ) : (
        <span key={idx}>{tok.t}</span>
      ),
    );
  });
  return <code className="font-mono">{out}</code>;
}

export function CodeBlock({
  code,
  lang,
  title,
  accent,
}: {
  code: string;
  lang: Lang;
  title?: string;
  accent?: "amber" | "mint";
}) {
  return (
    <div className="overflow-hidden rounded-lg border border-line bg-bg1">
      <div className="flex items-center gap-2 border-b border-line bg-bg2 px-3 py-1.5">
        <span
          className={`h-2 w-2 rounded-full ${
            accent === "mint" ? "bg-mint" : "bg-amber"
          }`}
        />
        <span className="font-mono text-[11px] text-mut">{title ?? lang}</span>
      </div>
      <pre className="overflow-x-auto p-3.5 text-[12.5px] leading-relaxed text-ink">
        <HighlightedCode code={code} lang={lang} />
      </pre>
    </div>
  );
}
