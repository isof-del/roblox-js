"use client";

import CodeMirror from "@uiw/react-codemirror";
import { createTheme } from "@uiw/codemirror-themes";
import { javascript } from "@codemirror/lang-javascript";
import { StreamLanguage } from "@codemirror/language";
import { lua } from "@codemirror/legacy-modes/mode/lua";
import { EditorView } from "@codemirror/view";
import { tags as t } from "@lezer/highlight";
import { useMemo } from "react";

export const rjTheme = createTheme({
  theme: "dark",
  settings: {
    background: "#0e1218",
    foreground: "#e8ecf3",
    caret: "#ffb224",
    selection: "rgba(255, 178, 36, 0.18)",
    selectionMatch: "rgba(255, 178, 36, 0.12)",
    lineHighlight: "rgba(141, 153, 172, 0.07)",
    gutterBackground: "#0e1218",
    gutterForeground: "#4d586b",
    gutterActiveForeground: "#8d99ac",
    fontFamily: "var(--font-jetbrains), ui-monospace, monospace",
  },
  styles: [
    { tag: [t.keyword, t.controlKeyword, t.operatorKeyword, t.moduleKeyword], color: "#ffb224" },
    { tag: [t.string, t.special(t.string)], color: "#3ddc97" },
    { tag: [t.number, t.bool, t.null], color: "#6ec1ff" },
    { tag: [t.comment, t.lineComment, t.blockComment], color: "#4d586b", fontStyle: "italic" },
    { tag: [t.function(t.variableName), t.function(t.propertyName)], color: "#ff8a3d" },
    { tag: [t.typeName, t.className], color: "#ffb224" },
    { tag: [t.propertyName], color: "#c9d4e3" },
    { tag: [t.variableName, t.definition(t.variableName)], color: "#e8ecf3" },
    { tag: [t.operator], color: "#8d99ac" },
    { tag: [t.punctuation, t.separator], color: "#6b788c" },
    { tag: [t.meta], color: "#ffb224" },
  ],
});

export function Editor({
  value,
  onChange,
  lang,
  readOnly = false,
}: {
  value: string;
  onChange?: (value: string) => void;
  lang: "js" | "lua";
  readOnly?: boolean;
}) {
  const extensions = useMemo(() => {
    const base =
      lang === "js"
        ? [javascript({ typescript: false, jsx: false })]
        : [StreamLanguage.define(lua)];
    return [...base, EditorView.lineWrapping];
  }, [lang]);

  return (
    <CodeMirror
      value={value}
      onChange={onChange}
      theme={rjTheme}
      extensions={extensions}
      readOnly={readOnly}
      basicSetup={{
        foldGutter: false,
        highlightActiveLine: !readOnly,
        autocompletion: false,
      }}
      style={{ height: "100%" }}
    />
  );
}
