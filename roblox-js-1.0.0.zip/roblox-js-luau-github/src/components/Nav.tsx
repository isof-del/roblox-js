"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { BookOpen, Boxes, FlaskConical } from "lucide-react";

const LINKS = [
  { href: "/playground", label: "Playground", icon: FlaskConical },
  { href: "/projects", label: "Projects", icon: Boxes },
  { href: "/docs", label: "Docs", icon: BookOpen },
];

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <rect x="1.5" y="1.5" width="29" height="29" rx="7" fill="#141a24" stroke="#2d3949" />
      <path
        d="M12.5 8.5 7 16l5.5 7.5"
        stroke="#ffb224"
        strokeWidth="2.6"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path
        d="M19.5 8.5 25 16l-5.5 7.5"
        stroke="#ff8a3d"
        strokeWidth="2.6"
        fill="none"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <circle cx="16" cy="16" r="1.7" fill="#e8ecf3" />
    </svg>
  );
}

export function Nav() {
  const pathname = usePathname();
  return (
    <header className="sticky top-0 z-40 border-b border-line bg-bg1/90 backdrop-blur">
      <div className="mx-auto flex h-14 max-w-6xl items-center gap-6 px-5">
        <Link href="/" className="flex items-center gap-2.5">
          <Logo />
          <span className="font-mono text-[15px] font-semibold tracking-tight">
            roblox<span className="text-amber">-</span>java
          </span>
          <span className="hidden rounded border border-line2 bg-bg2 px-1.5 py-0.5 font-mono text-[10px] text-mut sm:inline">
            v1.0.0
          </span>
        </Link>
        <nav className="flex flex-1 items-center gap-1">
          {LINKS.map((l) => {
            const active = pathname.startsWith(l.href);
            const Icon = l.icon;
            return (
              <Link
                key={l.href}
                href={l.href}
                className={`flex items-center gap-1.5 rounded-md px-3 py-1.5 text-[13px] font-medium transition-colors ${
                  active
                    ? "bg-bg3 text-amber"
                    : "text-mut hover:bg-bg2 hover:text-ink"
                }`}
              >
                <Icon size={14} strokeWidth={2.2} />
                {l.label}
              </Link>
            );
          })}
        </nav>
        <a
          href="/docs#getting-started"
          className="hidden items-center gap-1.5 rounded-md border border-amber/40 bg-amber/10 px-3 py-1.5 font-mono text-[12px] font-medium text-amber transition-colors hover:bg-amber/20 md:flex"
        >
          npm i -g roblox-java
        </a>
      </div>
    </header>
  );
}
