import Link from "next/link";
import { compileFile } from "@/compiler";
import { CodeBlock, HighlightedCode } from "@/components/CodeBlock";

const SECTIONS = [
  { id: "overview", label: "Overview" },
  { id: "getting-started", label: "Getting started" },
  { id: "cli", label: "CLI reference" },
  { id: "operators", label: "Operators" },
  { id: "statements", label: "Statements" },
  { id: "classes", label: "Classes" },
  { id: "modules", label: "Modules" },
  { id: "stdlib", label: "Standard library" },
  { id: "roblox", label: "Roblox APIs" },
  { id: "runtime", label: "Runtime reference" },
  { id: "escape-hatches", label: "Escape hatches" },
  { id: "limitations", label: "Limitations" },
];

const OPERATORS: [string, string, string][] = [
  ["a === b / a !== b", "a == b / a ~= b", "Identity becomes Luau equality"],
  ["!x", "not __rojava.bool(x)", "JS falsy values (0, \"\", NaN) are respected"],
  ["a && b / a || b", "a and b / a or b", "Short-circuit semantics preserved"],
  ["a ?? b", "if a ~= nil then a else b end", "Only nil/null triggers the fallback"],
  ["a ** b", "a ^ b", "Exponent"],
  ["x++ / x--", "x += 1 / x -= 1", "Compound assignment (Luau native)"],
  ["a << b, a >> b, a >>> b", "bit32.lshift / arshift / rshift", "32-bit, like JavaScript"],
  ["a & b, a | b, a ^ b", "bit32.band / bor / bxor", ""],
  ["typeof x", "typeof(x)", "Luau's typeof; typeof x === \"undefined\" becomes x == nil"],
  ["x instanceof C", "__rojava.instanceof(x, C)", "Walks the metatable chain"],
  ["key in obj", 'obj[key] ~= nil', ""],
  ["delete obj[k]", "obj[k] = nil", ""],
  ["a?.b / a?.m()", "guarded IIFE", "Returns nil when the receiver is nil"],
  ["c ? a : b", "if c then a else b end", "Luau if-expression"],
];

const STATEMENTS: [string, string][] = [
  ["let / const / var", "local declarations (block scoped)"],
  ["if / else if / else", "if / elseif / else"],
  ["while (c) {}", "while c do end"],
  ["do {} while (c)", "repeat until not (c)"],
  ["for (let i = 0; i < n; i++)", "numeric for i = 0, n - 1 do"],
  ["for (...) { ... } (general)", "while loop with update step"],
  ["for (const x of arr)", "ipairs for known arrays, __rojava.iter otherwise"],
  ["for (const k in obj)", "for k, _ in pairs(obj) do"],
  ["break / continue", "break / repeat-until lowering with flags"],
  ["switch / case / default", "fall-through flag + goto labels"],
  ["try / catch / finally", "pcall(function() ... end)"],
  ["throw expr", "error(expr, 0)"],
  ["function f(...) / arrow fns", "local function / anonymous function"],
  ["default params, rest (...xs)", "nil-checks / table.pack(...)"],
  ["destructuring (arrays, objects)", "temp table + indexed locals"],
];

const RUNTIME_FNS: [string, string][] = [
  ["toStr(v)", "JS-style stringification for template literals"],
  ["bool(v)", "JS truthiness (0, \"\", NaN, nil, false are falsy)"],
  ["array_push / pop / shift / unshift", "mutating array ops with JS return values"],
  ["array_indexOf / lastIndexOf / includes", "0-based search results"],
  ["array_join / slice / splice / concat", "copies where JS copies"],
  ["array_map / filter / reduce / reduceRight", "callbacks receive (value, index0)"],
  ["array_forEach / find / findIndex / some / every", ""],
  ["array_flat / fill / reverse / sort", "sort defaults to string comparison, like JS"],
  ["array_isArray(v)", "true for plain tables"],
  ["str_indexOf / includes / startsWith / endsWith", "0-based, plain-text search"],
  ["str_slice / substring / charAt / charCodeAt", ""],
  ["str_split(s, sep, limit)", ""],
  ["str_trim / trimStart / trimEnd", ""],
  ["str_padStart / padEnd / replace / replaceAll", "literal pattern semantics"],
  ["object_keys / values / entries / assign", ""],
  ["object_fromEntries / freeze", ""],
  ["Map.new / Set.new (+ methods)", "size via map_size(m) / set_size(s)"],
  ["iter(x)", "for-of driver for arrays, strings, Maps, Sets"],
  ["get(obj, key) / invoke(obj, name, ...)", "dynamic access for unknown receivers"],
  ["instanceof(obj, class)", "metatable chain walk"],
  ["json_stringify(v) / json_parse(s)", "compact JSON support"],
];

function compileForDoc(js: string) {
  return compileFile(js, "example.js").code.split("\n").slice(8).join("\n").trimEnd();
}

const CLASS_EXAMPLE = `class Weapon {
  ammo = 30;
  constructor(name) { this.name = name; }
  fire() { this.ammo -= 1; return this.ammo >= 0; }
}
class Railgun extends Weapon {
  fire() { return super.fire() && super.fire(); }
}
new Railgun("RG-7").fire();`;

const MODULE_EXAMPLE = `// util.js
export function double(n) { return n * 2; }
export const VERSION = "1.2.3";

// main.js
import { double, VERSION } from "./util";
print(double(21), VERSION);`;

export default function DocsPage() {
  const classOut = compileForDoc(CLASS_EXAMPLE);
  const moduleOut = compileForDoc(MODULE_EXAMPLE);

  return (
    <div className="mx-auto max-w-6xl px-5 py-10">
      <div className="grid gap-10 lg:grid-cols-[210px_minmax(0,1fr)]">
        {/* sidebar */}
        <aside className="hidden lg:block">
          <nav className="sticky top-20 space-y-0.5 border-l border-line pl-4">
            <p className="mb-2 font-mono text-[10.5px] uppercase tracking-[0.18em] text-dim">
              reference
            </p>
            {SECTIONS.map((s) => (
              <a
                key={s.id}
                href={`#${s.id}`}
                className="block rounded px-2 py-1 text-[12.5px] text-mut transition hover:bg-bg2 hover:text-amber"
              >
                {s.label}
              </a>
            ))}
          </nav>
        </aside>

        {/* content */}
        <div className="min-w-0 space-y-14">
          <section id="overview">
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-amber">
              documentation
            </p>
            <h1 className="mt-1.5 text-[30px] font-bold tracking-tight">
              roblox-java handbook
            </h1>
            <p className="mt-3 max-w-2xl text-[14px] leading-relaxed text-mut">
              roblox-java accepts modern JavaScript (ES2022 modules) and emits Luau
              suitable for Roblox. It tracks the spirit of roblox-ts — real classes,
              real standard-library semantics, a bundled runtime — while staying in
              plain JavaScript territory. Everything on this page reflects what the
              compiler that powers the <Link className="text-amber underline" href="/playground">playground</Link>{" "}
              actually does today.
            </p>
            <div className="mt-5 grid gap-3 sm:grid-cols-3">
              {[
                ["Parse", "Acorn · ES2022 · modules"],
                ["Transform", "classes, loops, try/catch, destructuring"],
                ["Emit", "Luau + _rojava runtime + Rojo project"],
              ].map(([t, d]) => (
                <div key={t} className="rounded-lg border border-line bg-bg1 p-4">
                  <p className="font-mono text-[12px] font-semibold text-amber">{t}</p>
                  <p className="mt-1 text-[12px] text-mut">{d}</p>
                </div>
              ))}
            </div>
          </section>

          <section id="getting-started">
            <h2 className="text-xl font-semibold tracking-tight">Getting started</h2>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-mut">
              The fastest way in is the <Link href="/playground" className="text-amber underline">playground</Link>:
              paste JavaScript, get Luau. For a persistent workspace, create a{" "}
              <Link href="/projects" className="text-amber underline">project</Link> — files
              are stored, builds are recorded, and output can be downloaded as a zip
              ready for Rojo. With the CLI (below), the same compiler runs on your machine.
            </p>
            <div className="mt-4 overflow-hidden rounded-lg border border-line bg-bg0">
              <div className="border-b border-line bg-bg2 px-3 py-1.5 font-mono text-[11px] text-dim">
                terminal
              </div>
              <pre className="p-4 font-mono text-[12.5px] leading-[1.9]">
                <span className="text-dim">$ </span>
                <span>npm i -g roblox-java</span>
                {"\n"}
                <span className="text-dim">$ </span>
                <span>rjava init my-game && cd my-game</span>
                {"\n"}
                <span className="text-dim">$ </span>
                <span>rjava build        </span>
                <span className="text-dim"># one-shot compile to out/</span>
                {"\n"}
                <span className="text-dim">$ </span>
                <span>rjava dev          </span>
                <span className="text-dim"># watch mode + Rojo sync</span>
              </pre>
            </div>
          </section>

          <section id="cli">
            <h2 className="text-xl font-semibold tracking-tight">CLI reference</h2>
            <div className="mt-3 overflow-hidden rounded-lg border border-line">
              <table className="w-full text-left text-[13px]">
                <thead className="bg-bg2 font-mono text-[11px] uppercase tracking-wider text-dim">
                  <tr>
                    <th className="px-4 py-2.5">Command</th>
                    <th className="px-4 py-2.5">Description</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line bg-bg1">
                  {[
                    ["rjava init <dir>", "Scaffold a project with src/main.js, default.project.json and package.json"],
                    ["rjava build", "Compile src/**/*.js to out/**/*.luau, emit the runtime and Rojo project"],
                    ["rjava dev", "Watch sources, recompile incrementally and serve the Rojo sourcemap"],
                    ["rjava check", "Type-free lint pass: parse + diagnostics only, exit code reflects errors"],
                    ["rjava runtime", "Print the _rojava.luau runtime for vendoring"],
                  ].map(([c, d]) => (
                    <tr key={c}>
                      <td className="px-4 py-2.5 font-mono text-[12px] text-amber">{c}</td>
                      <td className="px-4 py-2.5 text-mut">{d}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section id="operators">
            <h2 className="text-xl font-semibold tracking-tight">Operators</h2>
            <div className="mt-3 overflow-hidden rounded-lg border border-line">
              <table className="w-full text-left text-[13px]">
                <thead className="bg-bg2 font-mono text-[11px] uppercase tracking-wider text-dim">
                  <tr>
                    <th className="px-4 py-2.5">JavaScript</th>
                    <th className="px-4 py-2.5">Luau</th>
                    <th className="hidden px-4 py-2.5 md:table-cell">Notes</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line bg-bg1">
                  {OPERATORS.map(([js, lua, note]) => (
                    <tr key={js}>
                      <td className="px-4 py-2 font-mono text-[12px] text-ink">{js}</td>
                      <td className="px-4 py-2 font-mono text-[12px] text-mint">{lua}</td>
                      <td className="hidden px-4 py-2 text-[12px] text-mut md:table-cell">{note}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section id="statements">
            <h2 className="text-xl font-semibold tracking-tight">Statements</h2>
            <div className="mt-3 overflow-hidden rounded-lg border border-line">
              <table className="w-full text-left text-[13px]">
                <thead className="bg-bg2 font-mono text-[11px] uppercase tracking-wider text-dim">
                  <tr>
                    <th className="px-4 py-2.5">JavaScript</th>
                    <th className="px-4 py-2.5">Lowering</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-line bg-bg1">
                  {STATEMENTS.map(([js, lua]) => (
                    <tr key={js}>
                      <td className="px-4 py-2 font-mono text-[12px] text-ink">{js}</td>
                      <td className="px-4 py-2 text-[12.5px] text-mut">{lua}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            <p className="mt-3 max-w-2xl text-[12.5px] leading-relaxed text-dim">
              continue is lowered by wrapping loop bodies in{" "}
              <span className="font-mono text-mut">repeat … until true</span> blocks with a
              break flag; switch fall-through uses a flag and{" "}
              <span className="font-mono text-mut">goto</span> labels; try/catch becomes{" "}
              <span className="font-mono text-mut">pcall</span> (returns cannot cross the
              boundary — a warning is emitted).
            </p>
          </section>

          <section id="classes">
            <h2 className="text-xl font-semibold tracking-tight">Classes</h2>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-mut">
              Classes compile to the idiomatic Roblox metatable pattern.{" "}
              <span className="font-mono text-ink">.new</span> accepts an optional{" "}
              <span className="font-mono text-ink">self</span> so subclasses can reuse the
              same table; methods become colon functions and{" "}
              <span className="font-mono text-ink">super</span> resolves statically.
            </p>
            <div className="mt-4 grid gap-3 xl:grid-cols-2">
              <CodeBlock code={CLASS_EXAMPLE} lang="js" title="weapon.js" />
              <CodeBlock code={classOut} lang="lua" title="weapon.luau" accent="mint" />
            </div>
          </section>

          <section id="modules">
            <h2 className="text-xl font-semibold tracking-tight">Modules</h2>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-mut">
              ES modules map to Luau modules: relative imports become{" "}
              <span className="font-mono text-ink">require(script.Parent.…)</span>, named
              exports are collected into a returned table, and{" "}
              <span className="font-mono text-ink">export default</span> lands in the{" "}
              <span className="font-mono text-ink">.default</span> field.
            </p>
            <div className="mt-4 grid gap-3 xl:grid-cols-2">
              <CodeBlock code={MODULE_EXAMPLE} lang="js" title="main.js + util.js" />
              <CodeBlock code={moduleOut} lang="lua" title="main.luau" accent="mint" />
            </div>
          </section>

          <section id="stdlib">
            <h2 className="text-xl font-semibold tracking-tight">Standard library</h2>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-mut">
              The compiler infers arrays, strings, Maps, Sets and modules for local
              variables, then lowers method calls directly. Arrays are 1-based tables and
              element indexing is adjusted automatically (
              <span className="font-mono text-ink">arr[i]</span> →{" "}
              <span className="font-mono text-ink">arr[i + 1]</span>,{" "}
              <span className="font-mono text-ink">arr.length</span> →{" "}
              <span className="font-mono text-ink">#arr</span>). Unknown receivers fall back
              to dynamic runtime dispatch so common calls keep working.
            </p>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <CodeBlock
                code={`const xs = [3, 1, 2];
xs.push(4);
const big = xs.filter((n) => n > 1).map((n) => n * 10);
print(big.join(", ")); // "30, 20, 40"
print(xs.length);      // 4`}
                lang="js"
                title="arrays.js"
              />
              <CodeBlock
                code={`const s = "  Roblox  ";
print(s.trim().toUpperCase());
print(s.indexOf("blo"));   // 3
const parts = "a,b,c".split(",");
for (const ch of "hi") print(ch);`}
                lang="js"
                title="strings.js"
              />
            </div>
            <p className="mt-3 max-w-2xl text-[12.5px] leading-relaxed text-dim">
              Object statics (keys, values, entries, assign, fromEntries), JSON.stringify /
              parse, Math.* and console.* are all mapped.{" "}
              <span className="font-mono">new Map()</span> /{" "}
              <span className="font-mono">new Set()</span> lower to runtime classes with{" "}
              <span className="font-mono">.size</span> support.
            </p>
          </section>

          <section id="roblox">
            <h2 className="text-xl font-semibold tracking-tight">Roblox APIs</h2>
            <ul className="mt-3 max-w-2xl space-y-2 text-[13.5px] leading-relaxed text-mut">
              <li>
                <span className="font-mono text-ink">game</span>,{" "}
                <span className="font-mono text-ink">workspace</span>,{" "}
                <span className="font-mono text-ink">script</span> and{" "}
                <span className="font-mono text-ink">Enum</span> method calls use{" "}
                <span className="font-mono text-mint">colon syntax</span> automatically —{" "}
                <span className="font-mono">game.GetService("Players")</span> →{" "}
                <span className="font-mono text-mint">game:GetService("Players")</span>.
              </li>
              <li>
                Variables initialized from <span className="font-mono">Instance.new</span> or{" "}
                <span className="font-mono">GetService / WaitForChild / Clone / GetPlayers</span>{" "}
                are tracked as instances, so{" "}
                <span className="font-mono">part.Destroy()</span> compiles to{" "}
                <span className="font-mono text-mint">part:Destroy()</span>.
              </li>
              <li>
                <span className="font-mono">new Vector3(…)</span>,{" "}
                <span className="font-mono">new CFrame(…)</span> and 25+ datatypes lower to{" "}
                <span className="font-mono text-mint">X.new(…)</span>.
              </li>
              <li>
                Luau libraries (<span className="font-mono">math</span>,{" "}
                <span className="font-mono">table</span>, <span className="font-mono">task</span>,{" "}
                <span className="font-mono">Instance</span>, …) keep dot calls.
              </li>
            </ul>
          </section>

          <section id="runtime">
            <h2 className="text-xl font-semibold tracking-tight">Runtime reference</h2>
            <p className="mt-2 max-w-2xl text-[13.5px] leading-relaxed text-mut">
              Builds that need it emit <span className="font-mono text-ink">_rojava.luau</span>{" "}
              and each file requires it automatically. Highlights:
            </p>
            <div className="mt-3 overflow-hidden rounded-lg border border-line">
              <table className="w-full text-left text-[13px]">
                <tbody className="divide-y divide-line bg-bg1">
                  {RUNTIME_FNS.map(([fn, d]) => (
                    <tr key={fn}>
                      <td className="whitespace-nowrap px-4 py-2 font-mono text-[12px] text-amber">
                        {fn}
                      </td>
                      <td className="px-4 py-2 text-[12.5px] text-mut">{d}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>

          <section id="escape-hatches">
            <h2 className="text-xl font-semibold tracking-tight">Escape hatches</h2>
            <ul className="mt-3 max-w-2xl space-y-2 text-[13.5px] leading-relaxed text-mut">
              <li>
                Computed calls — <span className="font-mono text-ink">obj["fn"](a, b)</span> —
                always emit a plain dot call with no injected self.
              </li>
              <li>
                Any identifier that is not declared locally passes through as a Roblox global,
                so <span className="font-mono text-ink">task.spawn</span>,{" "}
                <span className="font-mono text-ink">pcall</span> and friends just work.
              </li>
              <li>
                Non-relative imports are emitted as raw{" "}
                <span className="font-mono text-ink">require("@scope/pkg")</span> so package
                ecosystems stay reachable.
              </li>
            </ul>
          </section>

          <section id="limitations">
            <h2 className="text-xl font-semibold tracking-tight">Known limitations</h2>
            <ul className="mt-3 max-w-2xl list-disc space-y-1.5 pl-5 text-[13.5px] leading-relaxed text-mut">
              <li>async/await, generators, tagged templates and getters/setters are rejected with diagnostics.</li>
              <li>Truthiness in raw conditions follows Lua (only nil/false are falsy); use <span className="font-mono">!!x</span> or comparisons when 0/"" matter.</li>
              <li>String + number concatenation needs one operand to be statically a string; otherwise use template literals.</li>
              <li>try/catch cannot propagate return/break across the pcall boundary.</li>
              <li>Fall-through into a default case requires the default to be last (it is reordered).</li>
              <li>Dynamic receivers get runtime dispatch — correct, but slower than a typed call.</li>
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
