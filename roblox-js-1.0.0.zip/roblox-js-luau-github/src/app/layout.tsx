import type { Metadata } from "next";
import type { ReactNode } from "react";
import { JetBrains_Mono, Sora } from "next/font/google";
import { Nav } from "@/components/Nav";
import "./globals.css";

const sora = Sora({
  subsets: ["latin"],
  variable: "--font-sora",
  display: "swap",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "roblox-java — JavaScript → Luau transpiler for Roblox",
  description:
    "roblox-java compiles JavaScript into Luau for Roblox: classes, arrays, strings, maps, modules and a full runtime library — like roblox-ts, but JavaScript.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" className={`${sora.variable} ${mono.variable}`}>
      <body className="bg-bg0 font-sans text-ink antialiased">
        <Nav />
        <main className="min-h-[calc(100vh-57px)]">{children}</main>
        <footer className="border-t border-line bg-bg1">
          <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-5 py-6 text-xs text-dim">
            <span className="font-mono">roblox-java v1.0.0 — JavaScript → Luau</span>
            <span>
              Not affiliated with Roblox Corporation or roblox-ts.{" "}
              <span className="text-mut">Built for the compiler-curious.</span>
            </span>
          </div>
        </footer>
      </body>
    </html>
  );
}
