import Link from "next/link";
import {
  ArrowDownRight,
  ArrowRight,
  Braces,
  FileJson2,
  FlaskConical,
  Radar,
  ScrollText,
  Terminal,
  Workflow,
  Wrench,
} from "lucide-react";
import { compileFile } from "@/compiler";
import { CodeBlock, HighlightedCode } from "@/components/CodeBlock";

const HERO_JS = `const part = Instance.new("Part");
part.Anchored = true;
part.Color = Color3.fromRGB(255, 178, 36);
part.Parent = workspace;

const greet = (name) => \`Hello, \${name}!\`;
print(greet("Roblox"));`;

const CLASS_JS = `class Enemy {
  hp = 10;
  hit(dmg) { this.hp -= dmg; }
}
class Ogre extends Enemy {
  hit(dmg) { super.hit(dmg / 2); }
}
new Ogre().hit(8);`;

const STATS = [
  { k: "120+", v: "syntax forms lowered" },
  { k: "70+", v: "runtime library functions" },
  { k: "4", v: "stage pipeline" },
  { k: "0", v: "build config required" },
];

const PIPELINE = [
  { n: "01", t: "Parse", d: "Acorn parses ES2022 modules into a typed AST, capturing precise source locations for diagnostics.", i: Braces },
  { n: "02", t: "Infer", d: "A lightweight dataflow pass tracks arrays, strings, Maps, modules and Roblox instances per local.", i: Radar },
  { n: "03", t: "Lower", d: "Classes become metatables, loops gain continue support, try/catch becomes pcall, switch gets a fall flag.", i: Workflow },
  { n: "04", t: "Emit", d: "Idiomatic Luau with 1-based arrays, colon calls on instances, and a require of the runtime module.", i: ScrollText },
];

export default function Home() {
  const heroOut = compileFile(HERO_JS, "hero.js");
  const classOut = compileFile(CLASS_JS, "enemy.js");

  return (
    <div>
      {/* hero */}
      <section className="blueprint relative overflow-hidden border-b border-line">
        <div className="pointer-events-none absolute -top-40 left-1/2 h-80 w-[700px] -translate-x-1/2 rounded-full bg-amber/10 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl gap-10 px-5 pb-16 pt-14 lg:grid-cols-[5fr_6fr] lg:gap-12">
          <div className="flex flex-col justify-center">
            <div className="mb-4 inline-flex w-fit items-center gap-2 rounded-full border border-line2 bg-bg1 px-3 py-1 font-mono text-[11px] text-mut">
              <span className="h-1.5 w-1.5 rounded-full bg-mint pulse-dot" />
              JavaScript in · Luau out · Roblox ready
            </div>
            <h1 className="text-[40px] font-bold leading-[1.05] tracking-tight sm:text-[52px]">
              Write JavaScript.
              <br />
              Ship <span className="text-amber">Luau</span>.
            </h1>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-mut">
              <span className="font-mono text-ink">roblox-java</span> is a
              JavaScript → Luau transpiler for Roblox, in the spirit of
              roblox-ts. Classes, arrays, template literals, maps, modules and
              try/catch — all lowered to clean Luau with a full runtime library.
            </p>
            <div className="mt-7 flex flex-wrap items-center gap-3">
              <Link
                href="/playground"
                className="flex items-center gap-2 rounded-md bg-amber px-4 py-2.5 text-[14px] font-semibold text-bg0 transition hover:bg-ember"
              >
                <FlaskConical size={16} strokeWidth={2.4} />
                Open the playground
              </Link>
              <Link
                href="/docs"
                className="flex items-center gap-2 rounded-md border border-line2 bg-bg1 px-4 py-2.5 text-[14px] font-medium text-ink transition hover:border-amber/50 hover:text-amber"
              >
                Read the docs
                <ArrowRight size={15} />
              </Link>
            </div>
            <dl className="mt-10 grid grid-cols-4 gap-3 border-t border-line pt-6">
              {STATS.map((s) => (
                <div key={s.v}>
                  <dt className="sr-only">{s.v}</dt>
                  <dd className="font-mono text-xl font-semibold text-amber">{s.k}</dd>
                  <dd className="mt-1 text-[11px] leading-tight text-dim">{s.v}</dd>
                </div>
              ))}
            </dl>
          </div>

          <div className="relative">
            <div className="glow-amber overflow-hidden rounded-xl border border-line bg-bg1">
              <div className="flex items-center justify-between border-b border-line bg-bg2 px-4 py-2">
                <span className="font-mono text-[11px] text-mut">src/main.js</span>
                <span className="rounded bg-amber/15 px-1.5 py-0.5 font-mono text-[10px] text-amber">
                  input
                </span>
              </div>
              <pre className="overflow-x-auto p-4 text-[12.5px] leading-relaxed">
                <HighlightedCode code={HERO_JS} lang="js" />
              </pre>
              <div className="flex items-center gap-2 border-y border-line bg-bg2/60 px-4 py-1.5">
                <ArrowDownRight size={13} className="text-amber" />
                <span className="font-mono text-[10.5px] uppercase tracking-wider text-dim">
                  roblox-java v1.0.0 · compiled live on this page
                </span>
              </div>
              <div className="flex items-center justify-between border-b border-line bg-bg2 px-4 py-2">
                <span className="font-mono text-[11px] text-mut">main.luau</span>
                <span className="rounded bg-mint/15 px-1.5 py-0.5 font-mono text-[10px] text-mint">
                  output
                </span>
              </div>
              <pre className="max-h-[300px] overflow-auto p-4 text-[12.5px] leading-relaxed">
                <HighlightedCode
                  code={heroOut.code.split("\n").slice(8).join("\n")}
                  lang="lua"
                />
              </pre>
            </div>
          </div>
        </div>
      </section>

      {/* pipeline */}
      <section className="border-b border-line bg-bg1/50">
        <div className="mx-auto max-w-6xl px-5 py-14">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-amber">
                the pipeline
              </p>
              <h2 className="mt-2 text-2xl font-semibold tracking-tight">
                Four stages between your JS and the Luau VM
              </h2>
            </div>
            <Terminal size={22} className="hidden text-dim sm:block" />
          </div>
          <ol className="grid gap-px overflow-hidden rounded-lg border border-line bg-line sm:grid-cols-2 lg:grid-cols-4">
            {PIPELINE.map((p) => (
              <li key={p.n} className="bg-bg1 p-5 transition-colors hover:bg-bg2">
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] text-dim">{p.n}</span>
                  <p.i className="text-amber" size={17} />
                </div>
                <h3 className="mt-4 text-[15px] font-semibold">{p.t}</h3>
                <p className="mt-1.5 text-[12.5px] leading-relaxed text-mut">{p.d}</p>
              </li>
            ))}
          </ol>
        </div>
      </section>

      {/* features bento */}
      <section className="mx-auto max-w-6xl px-5 py-14">
        <div className="mb-8">
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-amber">
            what ships in the box
          </p>
          <h2 className="mt-2 text-2xl font-semibold tracking-tight">
            A full toolchain, not a string replace
          </h2>
        </div>
        <div className="grid gap-4 lg:grid-cols-5">
          <div className="rounded-lg border border-line bg-bg1 p-5 lg:col-span-3">
            <div className="flex items-center gap-2">
              <Wrench size={16} className="text-amber" />
              <h3 className="text-[15px] font-semibold">Classes lower to real metatables</h3>
            </div>
            <p className="mt-1.5 max-w-lg text-[12.5px] text-mut">
              Constructors, field initializers, inheritance and{" "}
              <span className="font-mono text-ink">super</span> compile to the
              standard Roblox OOP idiom — colon methods,{" "}
              <span className="font-mono text-ink">__index</span> chains and a{" "}
              <span className="font-mono text-ink">.new</span> that accepts an
              existing <span className="font-mono text-ink">self</span>.
            </p>
            <div className="mt-4 grid gap-3 md:grid-cols-2">
              <CodeBlock code={CLASS_JS} lang="js" title="enemy.js" />
              <CodeBlock
                code={classOut.code.split("\n").slice(8).join("\n")}
                lang="lua"
                title="enemy.luau"
                accent="mint"
              />
            </div>
          </div>
          <div className="flex flex-col gap-4 lg:col-span-2">
            <div className="rounded-lg border border-line bg-bg1 p-5">
              <div className="flex items-center gap-2">
                <FileJson2 size={16} className="text-amber" />
                <h3 className="text-[15px] font-semibold">Rojo-ready project output</h3>
              </div>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mut">
                Every build emits a <span className="font-mono text-ink">default.project.json</span>{" "}
                mapping your sources into ReplicatedStorage, plus a shared{" "}
                <span className="font-mono text-ink">_rojava.luau</span> runtime module.
              </p>
              <pre className="mt-3 overflow-x-auto rounded-md border border-line bg-bg0 p-3 text-[11.5px] leading-relaxed">
                <HighlightedCode
                  code={`{ "name": "my-game",
  "tree": { "$className": "DataModel",
    "ReplicatedStorage": { "$className": "ReplicatedStorage",
      "my-game": { "$path": "src" } } } }`}
                  lang="json"
                />
              </pre>
            </div>
            <div className="rounded-lg border border-line bg-bg1 p-5">
              <div className="flex items-center gap-2">
                <Radar size={16} className="text-amber" />
                <h3 className="text-[15px] font-semibold">Honest diagnostics</h3>
              </div>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-mut">
                Unsupported syntax — getters, async, regex, labels — is reported
                with file, line and column instead of silently miscompiled.
                Warnings flag footguns like implicit globals.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* quickstart */}
      <section className="border-t border-line bg-bg1/50">
        <div className="mx-auto grid max-w-6xl gap-8 px-5 py-14 lg:grid-cols-2">
          <div>
            <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-amber">
              quickstart
            </p>
            <h2 className="mt-2 text-2xl font-semibold tracking-tight">
              From npm to a running place
            </h2>
            <p className="mt-3 max-w-md text-[14px] leading-relaxed text-mut">
              The CLI mirrors the workflow you know: initialize a project, write
              JavaScript under <span className="font-mono text-ink">src/</span>,
              and let <span className="font-mono text-ink">rjava dev</span> watch
              and sync with Rojo. Or skip it all and use the in-browser
              playground — the exact same compiler runs there.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Link
                href="/projects"
                className="flex items-center gap-2 rounded-md border border-line2 bg-bg2 px-4 py-2 text-[13px] font-medium text-ink transition hover:border-amber/50 hover:text-amber"
              >
                Create a project
                <ArrowRight size={14} />
              </Link>
              <Link
                href="/docs#cli"
                className="px-2 py-2 text-[13px] text-mut underline-offset-4 transition hover:text-amber hover:underline"
              >
                CLI reference →
              </Link>
            </div>
          </div>
          <div className="overflow-hidden rounded-lg border border-line bg-bg0">
            <div className="flex items-center gap-1.5 border-b border-line bg-bg2 px-3 py-2">
              <span className="h-2.5 w-2.5 rounded-full bg-coral/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-amber/70" />
              <span className="h-2.5 w-2.5 rounded-full bg-mint/70" />
              <span className="ml-2 font-mono text-[11px] text-dim">zsh — my-game</span>
            </div>
            <pre className="p-4 font-mono text-[12.5px] leading-[1.9]">
              <span className="text-dim">$ </span>
              <span className="text-ink">npm i -g roblox-java</span>
              {"\n"}
              <span className="text-dim">$ </span>
              <span className="text-ink">rjava init my-game</span>
              {"\n"}
              <span className="text-mint">✓ Created my-game/ with src/main.js</span>
              {"\n"}
              <span className="text-dim">$ </span>
              <span className="text-ink">cd my-game && rjava dev</span>
              {"\n"}
              <span className="text-mint">✓ Watching src/ — 1 file compiled in 3.2 ms</span>
              {"\n"}
              <span className="text-mint">✓ Rojo sync → ReplicatedStorage.my-game</span>
              {"\n"}
              <span className="text-amber">➜ In-game: Hello, Roblox!</span>
            </pre>
          </div>
        </div>
      </section>
    </div>
  );
}
