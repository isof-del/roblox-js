import { db } from "@/db";
import { builds, projectFiles, projects } from "@/db/schema";
import { desc, eq, sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

const STARTER_FILE = `// Welcome to your roblox-java project.
// Press "Build" to transpile every file to Luau.

const message = "Hello from roblox-java!";

function greet(name) {
	return \`\${message} Nice to meet you, \${name}.\`;
}

print(greet("Roblox"));
`;

export async function GET() {
  const rows = await db
    .select({
      id: projects.id,
      name: projects.name,
      description: projects.description,
      createdAt: projects.createdAt,
      updatedAt: projects.updatedAt,
      fileCount: sql<number>`cast(count(distinct ${projectFiles.id}) as int)`,
      buildCount: sql<number>`cast(count(distinct ${builds.id}) as int)`,
    })
    .from(projects)
    .leftJoin(projectFiles, eq(projectFiles.projectId, projects.id))
    .leftJoin(builds, eq(builds.projectId, projects.id))
    .groupBy(projects.id)
    .orderBy(desc(projects.updatedAt));
  return Response.json({ projects: rows });
}

export async function POST(req: Request) {
  let body: { name?: string; description?: string } = {};
  try {
    body = await req.json();
  } catch {
    /* empty body */
  }
  const name = (body.name ?? "").trim().slice(0, 80);
  if (!name) {
    return Response.json({ error: "Project name is required" }, { status: 400 });
  }
  const [project] = await db
    .insert(projects)
    .values({ name, description: (body.description ?? "").slice(0, 280) })
    .returning();
  await db.insert(projectFiles).values({
    projectId: project.id,
    name: "main.js",
    content: STARTER_FILE,
    sort: 0,
  });
  return Response.json({ project }, { status: 201 });
}
