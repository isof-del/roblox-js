import { db } from "@/db";
import { projectFiles, projects } from "@/db/schema";
import { and, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string; fileId: string }> };

export async function PATCH(req: Request, { params }: Params) {
  const { id: rawId, fileId: rawFileId } = await params;
  const id = Number(rawId);
  const fileId = Number(rawFileId);
  const body = await req.json().catch(() => ({}));
  const patch: { name?: string; content?: string } = {};
  if (typeof body.content === "string") patch.content = body.content;
  if (typeof body.name === "string" && body.name.trim()) {
    const name = body.name.trim();
    if (!/^[\w./-]+\.js$/.test(name)) {
      return Response.json({ error: "File name must end in .js" }, { status: 400 });
    }
    patch.name = name;
  }
  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Nothing to update" }, { status: 400 });
  }
  const [file] = await db
    .update(projectFiles)
    .set(patch)
    .where(and(eq(projectFiles.id, fileId), eq(projectFiles.projectId, id)))
    .returning();
  if (!file) return Response.json({ error: "File not found" }, { status: 404 });
  await db.update(projects).set({ updatedAt: new Date() }).where(eq(projects.id, id));
  return Response.json({ file });
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id: rawId, fileId: rawFileId } = await params;
  const id = Number(rawId);
  const fileId = Number(rawFileId);
  await db
    .delete(projectFiles)
    .where(and(eq(projectFiles.id, fileId), eq(projectFiles.projectId, id)));
  return Response.json({ ok: true });
}
