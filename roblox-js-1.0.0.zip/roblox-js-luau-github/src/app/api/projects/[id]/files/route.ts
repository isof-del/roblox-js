import { db } from "@/db";
import { projectFiles, projects } from "@/db/schema";
import { asc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function POST(req: Request, { params }: Params) {
  const { id: rawId } = await params;
  const id = Number(rawId);
  const body = await req.json().catch(() => ({}));
  const name = typeof body.name === "string" ? body.name.trim() : "";
  if (!/^[\w./-]+\.js$/.test(name)) {
    return Response.json(
      { error: "File name must end in .js and use only letters, numbers, dots, dashes, slashes" },
      { status: 400 },
    );
  }
  const existing = await db
    .select()
    .from(projectFiles)
    .where(eq(projectFiles.projectId, id))
    .orderBy(asc(projectFiles.sort));
  if (existing.some((f) => f.name === name)) {
    return Response.json({ error: "A file with that name already exists" }, { status: 409 });
  }
  const maxSort = existing.reduce((m, f) => Math.max(m, f.sort), 0);
  const [file] = await db
    .insert(projectFiles)
    .values({
      projectId: id,
      name,
      content: typeof body.content === "string" ? body.content : `// ${name}\n`,
      sort: maxSort + 1,
    })
    .returning();
  await db.update(projects).set({ updatedAt: new Date() }).where(eq(projects.id, id));
  return Response.json({ file }, { status: 201 });
}


