import { db } from "@/db";
import { builds, projectFiles, projects } from "@/db/schema";
import { asc, desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

async function loadProject(id: number) {
  const [project] = await db.select().from(projects).where(eq(projects.id, id));
  return project ?? null;
}

export async function GET(_req: Request, { params }: Params) {
  const { id: rawId } = await params;
  const id = Number(rawId);
  if (!Number.isFinite(id)) {
    return Response.json({ error: "Invalid project id" }, { status: 400 });
  }
  const project = await loadProject(id);
  if (!project) return Response.json({ error: "Project not found" }, { status: 404 });
  const files = await db
    .select()
    .from(projectFiles)
    .where(eq(projectFiles.projectId, id))
    .orderBy(asc(projectFiles.sort), asc(projectFiles.id));
  const recentBuilds = await db
    .select()
    .from(builds)
    .where(eq(builds.projectId, id))
    .orderBy(desc(builds.createdAt), desc(builds.id))
    .limit(20);
  return Response.json({ project, files, builds: recentBuilds });
}

export async function PATCH(req: Request, { params }: Params) {
  const { id: rawId } = await params;
  const id = Number(rawId);
  const body = await req.json().catch(() => ({}));
  const patch: { name?: string; description?: string; updatedAt?: Date } = {};
  if (typeof body.name === "string" && body.name.trim()) patch.name = body.name.trim().slice(0, 80);
  if (typeof body.description === "string") patch.description = body.description.slice(0, 280);
  if (Object.keys(patch).length === 0) {
    return Response.json({ error: "Nothing to update" }, { status: 400 });
  }
  patch.updatedAt = new Date();
  const [project] = await db.update(projects).set(patch).where(eq(projects.id, id)).returning();
  if (!project) return Response.json({ error: "Project not found" }, { status: 404 });
  return Response.json({ project });
}

export async function DELETE(_req: Request, { params }: Params) {
  const { id: rawId } = await params;
  const id = Number(rawId);
  await db.delete(projects).where(eq(projects.id, id));
  return Response.json({ ok: true });
}
