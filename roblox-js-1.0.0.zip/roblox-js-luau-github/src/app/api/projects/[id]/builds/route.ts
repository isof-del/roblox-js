import { db } from "@/db";
import { builds } from "@/db/schema";
import { desc, eq } from "drizzle-orm";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ id: string }> };

export async function POST(req: Request, { params }: Params) {
  const { id: rawId } = await params;
  const id = Number(rawId);
  const body = await req.json().catch(() => ({}));
  const [build] = await db
    .insert(builds)
    .values({
      projectId: id,
      status: Number(body.errorCount ?? 0) > 0 ? "failed" : "success",
      outputCount: Math.round(Number(body.outputCount ?? 0)),
      diagnosticCount: Math.round(Number(body.diagnosticCount ?? 0)),
      errorCount: Math.round(Number(body.errorCount ?? 0)),
      durationMs: Math.round(Number(body.durationMs ?? 0)),
    })
    .returning();
  return Response.json({ build }, { status: 201 });
}

export async function GET(_req: Request, { params }: Params) {
  const { id: rawId } = await params;
  const id = Number(rawId);
  const rows = await db
    .select()
    .from(builds)
    .where(eq(builds.projectId, id))
    .orderBy(desc(builds.createdAt), desc(builds.id))
    .limit(50);
  return Response.json({ builds: rows });
}
