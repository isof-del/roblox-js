"use client";

import dynamic from "next/dynamic";
import Link from "next/link";
import { useParams } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  Check,
  CircleAlert,
  Copy,
  Download,
  FileCode2,
  FileJson2,
  FilePlus2,
  Hammer,
  Info,
  Library,
  Pencil,
  Save,
  Trash2,
  X,
} from "lucide-react";
import { compileProject } from "@/compiler";
import type { CompileResult, OutputFile } from "@/compiler";
import JSZip from "jszip";

const Editor = dynamic(() => import("@/components/Editor").then((m) => m.Editor), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-sm text-dim">
      Loading editor…
    </div>
  ),
});

interface FileRow {
  id: number;
  name: string;
  content: string;
  sort: number;
}

interface BuildRow {
  id: number;
  status: string;
  outputCount: number;
  diagnosticCount: number;
  errorCount: number;
  durationMs: number;
  createdAt: string;
}

interface ProjectRow {
  id: number;
  name: string;
  description: string;
}

type PanelTab = "output" | "diagnostics" | "history";

export default function ProjectWorkspace() {
  const params = useParams<{ id: string }>();
  const projectId = Number(params.id);

  const [project, setProject] = useState<ProjectRow | null>(null);
  const [files, setFiles] = useState<FileRow[]>([]);
  const [buildRows, setBuildRows] = useState<BuildRow[]>([]);
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [drafts, setDrafts] = useState<Record<number, string>>({});
  const [dirty, setDirty] = useState(false);
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved">("idle");
  const [build, setBuild] = useState<CompileResult | null>(null);
  const [panelTab, setPanelTab] = useState<PanelTab>("output");
  const [activeOutput, setActiveOutput] = useState<string>("");
  const [newFileName, setNewFileName] = useState("");
  const [addingFile, setAddingFile] = useState(false);
  const [fileError, setFileError] = useState<string | null>(null);
  const [renamingId, setRenamingId] = useState<number | null>(null);
  const [renameValue, setRenameValue] = useState("");
  const [copied, setCopied] = useState(false);
  const [loaded, setLoaded] = useState(false);

  const load = useCallback(async () => {
    const res = await fetch(`/api/projects/${projectId}`);
    if (!res.ok) return;
    const data = await res.json();
    setProject(data.project);
    setFiles(data.files);
    setBuildRows(data.builds);
    setSelectedId((cur) => cur ?? data.files[0]?.id ?? null);
    setLoaded(true);
  }, [projectId]);

  useEffect(() => {
    load();
  }, [load]);

  const selected = files.find((f) => f.id === selectedId) ?? null;
  const selectedContent = selected
    ? drafts[selected.id] ?? selected.content
    : "";

  const editContent = (value: string) => {
    if (!selected) return;
    setDrafts((d) => ({ ...d, [selected.id]: value }));
    setDirty(true);
    setSaveState("idle");
  };

  const saveFile = async () => {
    if (!selected) return;
    setSaveState("saving");
    const res = await fetch(`/api/projects/${projectId}/files/${selected.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content: selectedContent }),
    });
    if (res.ok) {
      setFiles((fs) =>
        fs.map((f) => (f.id === selected.id ? { ...f, content: selectedContent } : f)),
      );
      setDrafts((d) => {
        const next = { ...d };
        delete next[selected.id];
        return next;
      });
      setDirty(false);
      setSaveState("saved");
      setTimeout(() => setSaveState("idle"), 1500);
    }
  };

  const addFile = async () => {
    const name = newFileName.trim().endsWith(".js")
      ? newFileName.trim()
      : `${newFileName.trim()}.js`;
    const res = await fetch(`/api/projects/${projectId}/files`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    const data = await res.json();
    if (!res.ok) {
      setFileError(data.error ?? "Could not create file");
      return;
    }
    setFileError(null);
    setNewFileName("");
    setAddingFile(false);
    await load();
    setSelectedId(data.file.id);
  };

  const deleteFile = async (id: number) => {
    await fetch(`/api/projects/${projectId}/files/${id}`, { method: "DELETE" });
    if (selectedId === id) setSelectedId(null);
    await load();
  };

  const renameFile = async (id: number) => {
    const name = renameValue.trim().endsWith(".js")
      ? renameValue.trim()
      : `${renameValue.trim()}.js`;
    const res = await fetch(`/api/projects/${projectId}/files/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name }),
    });
    setRenamingId(null);
    if (res.ok) load();
  };

  const buildSources = useCallback(() => {
    const sources = files.map((f) => ({
      name: f.name,
      content: drafts[f.id] ?? f.content,
    }));
    const result = compileProject(sources, {
      projectName: project?.name ?? "roblox-java-project",
      includeRuntime: true,
    });
    setBuild(result);
    setActiveOutput(result.outputs[0]?.path ?? "");
    setPanelTab("output");
    void fetch(`/api/projects/${projectId}/builds`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        outputCount: result.outputs.length,
        diagnosticCount: result.diagnostics.length,
        errorCount: result.diagnostics.filter((d) => d.severity === "error").length,
        durationMs: Math.round(result.timeMs * 10) / 10,
      }),
    }).then((r) => r.json().then((d) => d.build && setBuildRows((b) => [d.build, ...b])));
  }, [files, drafts, project, projectId]);

  const downloadZip = async () => {
    if (!build) return;
    const zip = new JSZip();
    for (const o of build.outputs) zip.file(o.path, o.content);
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${project?.name ?? "project"}-build.zip`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const copyOutput = async () => {
    const o = build?.outputs.find((x) => x.path === activeOutput);
    if (!o) return;
    await navigator.clipboard.writeText(o.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  const outputForView = useMemo<OutputFile | null>(
    () => build?.outputs.find((o) => o.path === activeOutput) ?? null,
    [build, activeOutput],
  );

  const errors = build?.diagnostics.filter((d) => d.severity === "error") ?? [];
  const warnings = build?.diagnostics.filter((d) => d.severity === "warning") ?? [];
  const infos = build?.diagnostics.filter((d) => d.severity === "info") ?? [];

  if (!loaded) {
    return (
      <div className="mx-auto max-w-6xl px-5 py-16 text-center font-mono text-sm text-dim">
        Loading workspace…
      </div>
    );
  }

  if (!project) {
    return (
      <div className="mx-auto max-w-6xl px-5 py-16 text-center">
        <p className="text-mut">Project not found.</p>
        <Link href="/projects" className="mt-2 inline-block text-amber underline">
          Back to projects
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1500px] px-4 py-4">
      {/* header */}
      <div className="mb-3 flex flex-wrap items-center gap-3">
        <Link
          href="/projects"
          className="flex items-center gap-1 rounded-md border border-line bg-bg1 px-2.5 py-1.5 text-[12px] text-mut transition hover:text-amber"
        >
          <ArrowLeft size={13} />
          Projects
        </Link>
        <h1 className="font-mono text-[17px] font-semibold">{project.name}</h1>
        {project.description && (
          <span className="hidden truncate text-[12.5px] text-dim md:inline">
            {project.description}
          </span>
        )}
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={saveFile}
            disabled={!selected || (!dirty && saveState !== "saving")}
            className="flex items-center gap-1.5 rounded-md border border-line2 bg-bg1 px-3 py-1.5 text-[12.5px] font-medium text-mut transition enabled:hover:border-amber/50 enabled:hover:text-amber disabled:opacity-40"
          >
            {saveState === "saved" ? (
              <Check size={13} className="text-mint" />
            ) : (
              <Save size={13} />
            )}
            {saveState === "saving" ? "Saving…" : saveState === "saved" ? "Saved" : "Save"}
          </button>
          <button
            onClick={buildSources}
            className="flex items-center gap-1.5 rounded-md bg-amber px-3.5 py-1.5 text-[12.5px] font-semibold text-bg0 transition hover:bg-ember"
          >
            <Hammer size={13} strokeWidth={2.5} />
            Build project
          </button>
        </div>
      </div>

      <div className="grid gap-3 lg:grid-cols-[230px_minmax(0,1fr)_400px]">
        {/* file list */}
        <aside className="flex max-h-[calc(100vh-160px)] flex-col overflow-hidden rounded-lg border border-line bg-bg1">
          <div className="flex items-center justify-between border-b border-line bg-bg2 px-3 py-2">
            <span className="font-mono text-[11px] uppercase tracking-wider text-dim">
              files
            </span>
            <button
              onClick={() => setAddingFile((v) => !v)}
              className="rounded p-1 text-mut transition hover:bg-bg3 hover:text-amber"
              title="New file"
            >
              <FilePlus2 size={14} />
            </button>
          </div>
          {addingFile && (
            <div className="border-b border-line p-2">
              <input
                autoFocus
                value={newFileName}
                onChange={(e) => setNewFileName(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addFile()}
                placeholder="util.js"
                className="w-full rounded border border-line2 bg-bg2 px-2 py-1.5 font-mono text-[12px] text-ink outline-none focus:border-amber/60"
              />
              {fileError && <p className="mt-1 text-[11px] text-coral">{fileError}</p>}
              <div className="mt-1.5 flex gap-1.5">
                <button
                  onClick={addFile}
                  className="flex-1 rounded bg-amber px-2 py-1 text-[11.5px] font-semibold text-bg0"
                >
                  Add
                </button>
                <button
                  onClick={() => setAddingFile(false)}
                  className="rounded border border-line2 px-2 py-1 text-[11.5px] text-mut"
                >
                  Cancel
                </button>
              </div>
            </div>
          )}
          <ul className="min-h-0 flex-1 overflow-auto p-1.5">
            {files.map((f) => (
              <li key={f.id}>
                {renamingId === f.id ? (
                  <div className="flex items-center gap-1 px-1 py-0.5">
                    <input
                      autoFocus
                      value={renameValue}
                      onChange={(e) => setRenameValue(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === "Enter") renameFile(f.id);
                        if (e.key === "Escape") setRenamingId(null);
                      }}
                      className="w-full rounded border border-amber/50 bg-bg2 px-1.5 py-1 font-mono text-[12px] text-ink outline-none"
                    />
                  </div>
                ) : (
                  <div
                    className={`group flex cursor-pointer items-center gap-1.5 rounded px-2 py-1.5 text-[12.5px] transition ${
                      selectedId === f.id
                        ? "bg-bg3 text-amber"
                        : "text-mut hover:bg-bg2 hover:text-ink"
                    }`}
                    onClick={() => setSelectedId(f.id)}
                  >
                    <FileCode2 size={13} className="shrink-0" />
                    <span className="min-w-0 flex-1 truncate font-mono">{f.name}</span>
                    {drafts[f.id] !== undefined && drafts[f.id] !== f.content && (
                      <span className="h-1.5 w-1.5 shrink-0 rounded-full bg-amber" title="Unsaved changes" />
                    )}
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setRenamingId(f.id);
                        setRenameValue(f.name);
                      }}
                      className="hidden rounded p-0.5 text-dim hover:text-amber group-hover:block"
                      title="Rename"
                    >
                      <Pencil size={11} />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteFile(f.id);
                      }}
                      className="hidden rounded p-0.5 text-dim hover:text-coral group-hover:block"
                      title="Delete"
                    >
                      <X size={11} />
                    </button>
                  </div>
                )}
              </li>
            ))}
            {files.length === 0 && (
              <li className="px-2 py-6 text-center text-[12px] text-dim">
                No files. Add one with the + button.
              </li>
            )}
          </ul>
        </aside>

        {/* editor */}
        <section className="flex max-h-[calc(100vh-160px)] min-h-[480px] flex-col overflow-hidden rounded-lg border border-line bg-bg1">
          <div className="flex items-center justify-between border-b border-line bg-bg2 px-3 py-2">
            <span className="font-mono text-[12px] text-mut">
              {selected ? selected.name : "no file selected"}
            </span>
            {selected && dirty && (
              <span className="font-mono text-[10.5px] text-amber">● unsaved</span>
            )}
          </div>
          <div className="min-h-0 flex-1">
            {selected ? (
              <Editor value={selectedContent} onChange={editContent} lang="js" />
            ) : (
              <div className="flex h-full items-center justify-center text-[13px] text-dim">
                Select or create a file to start editing.
              </div>
            )}
          </div>
        </section>

        {/* build panel */}
        <section className="flex max-h-[calc(100vh-160px)] min-h-[480px] flex-col overflow-hidden rounded-lg border border-line bg-bg1">
          <div className="flex items-center border-b border-line bg-bg2">
            {(
              [
                { id: "output", label: "Output", icon: Library },
                { id: "diagnostics", label: `Diagnostics`, icon: AlertTriangle },
                { id: "history", label: "History", icon: Activity },
              ] as { id: PanelTab; label: string; icon: typeof Library }[]
            ).map((tab) => (
              <button
                key={tab.id}
                onClick={() => setPanelTab(tab.id)}
                className={`flex items-center gap-1.5 border-b-2 px-3.5 py-2 text-[12px] font-medium transition ${
                  panelTab === tab.id
                    ? "border-amber text-amber"
                    : "border-transparent text-dim hover:text-mut"
                }`}
              >
                <tab.icon size={12.5} />
                {tab.label}
                {tab.id === "diagnostics" && build && (
                  <span className="rounded bg-bg3 px-1 font-mono text-[10px]">
                    {build.diagnostics.length}
                  </span>
                )}
              </button>
            ))}
          </div>

          {panelTab === "output" && (
            <div className="flex min-h-0 flex-1 flex-col">
              {!build ? (
                <div className="flex flex-1 flex-col items-center justify-center gap-2 p-8 text-center">
                  <Hammer size={22} className="text-dim" />
                  <p className="text-[13px] text-mut">No build yet.</p>
                  <p className="max-w-[240px] text-[11.5px] text-dim">
                    Press <span className="font-mono text-amber">Build project</span> to
                    transpile every file to Luau.
                  </p>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-2 border-b border-line bg-bg0/40 px-2 py-1.5">
                    <span className="font-mono text-[10.5px] text-mint">
                      ✓ {build.outputs.length} files · {build.timeMs.toFixed(1)} ms
                    </span>
                    <div className="ml-auto flex gap-1">
                      <button
                        onClick={copyOutput}
                        className="rounded p-1 text-dim transition hover:text-amber"
                        title="Copy active output"
                      >
                        {copied ? <Check size={13} className="text-mint" /> : <Copy size={13} />}
                      </button>
                      <button
                        onClick={downloadZip}
                        className="rounded p-1 text-dim transition hover:text-amber"
                        title="Download build as .zip"
                      >
                        <Download size={13} />
                      </button>
                    </div>
                  </div>
                  <div className="flex min-h-0 flex-1 flex-col">
                    <div className="max-h-28 overflow-auto border-b border-line bg-bg0/30 p-1.5">
                      {build.outputs.map((o) => (
                        <button
                          key={o.path}
                          onClick={() => setActiveOutput(o.path)}
                          className={`flex w-full items-center gap-1.5 rounded px-2 py-1 font-mono text-[11.5px] transition ${
                            activeOutput === o.path
                              ? "bg-bg3 text-amber"
                              : "text-mut hover:bg-bg2"
                          }`}
                        >
                          {o.kind === "runtime" ? (
                            <Library size={11} />
                          ) : o.kind === "config" ? (
                            <FileJson2 size={11} />
                          ) : (
                            <FileCode2 size={11} />
                          )}
                          {o.path}
                        </button>
                      ))}
                    </div>
                    <div className="min-h-0 flex-1 overflow-auto">
                      {outputForView &&
                        (outputForView.path.endsWith(".luau") ? (
                          <Editor value={outputForView.content} lang="lua" readOnly />
                        ) : (
                          <pre className="p-3 font-mono text-[12px] leading-relaxed text-ink">
                            {outputForView.content}
                          </pre>
                        ))}
                    </div>
                  </div>
                </>
              )}
            </div>
          )}

          {panelTab === "diagnostics" && (
            <div className="min-h-0 flex-1 overflow-auto p-2">
              {!build && (
                <p className="p-4 text-center text-[12px] text-dim">
                  Run a build to see diagnostics.
                </p>
              )}
              {build && build.diagnostics.length === 0 && (
                <p className="p-4 font-mono text-[12px] text-mint">
                  ✓ clean build — no problems reported
                </p>
              )}
              {build?.diagnostics.map((d, i) => (
                <div key={i} className="flex items-start gap-2 rounded px-2 py-1.5 hover:bg-bg2">
                  {d.severity === "error" ? (
                    <CircleAlert size={13} className="mt-0.5 shrink-0 text-coral" />
                  ) : d.severity === "warning" ? (
                    <AlertTriangle size={13} className="mt-0.5 shrink-0 text-amber" />
                  ) : (
                    <Info size={13} className="mt-0.5 shrink-0 text-sky" />
                  )}
                  <div className="min-w-0">
                    <p className="font-mono text-[11.5px] text-ink">{d.message}</p>
                    <p className="font-mono text-[10.5px] text-dim">
                      {d.file}:{d.line}:{d.column}
                    </p>
                  </div>
                </div>
              ))}
              {build && (
                <p className="mt-2 border-t border-line px-2 pt-2 font-mono text-[10.5px] text-dim">
                  {errors.length} errors · {warnings.length} warnings · {infos.length} notes
                </p>
              )}
            </div>
          )}

          {panelTab === "history" && (
            <div className="min-h-0 flex-1 overflow-auto p-2">
              {buildRows.length === 0 && (
                <p className="p-4 text-center text-[12px] text-dim">No builds recorded yet.</p>
              )}
              <ul className="space-y-1.5">
                {buildRows.map((b) => (
                  <li
                    key={b.id}
                    className="flex items-center gap-2.5 rounded-md border border-line bg-bg0/40 px-3 py-2"
                  >
                    <span
                      className={`h-2 w-2 shrink-0 rounded-full ${
                        b.status === "success" ? "bg-mint" : "bg-coral"
                      }`}
                    />
                    <span className="font-mono text-[11.5px] text-ink">
                      {b.status === "success" ? "success" : "failed"}
                    </span>
                    <span className="font-mono text-[10.5px] text-dim">
                      {b.outputCount} out · {b.errorCount} err · {b.durationMs.toFixed(1)} ms
                    </span>
                    <span className="ml-auto font-mono text-[10.5px] text-dim">
                      {new Date(b.createdAt).toLocaleTimeString()}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </section>
      </div>
    </div>
  );
}
