"use client";

import Link from "next/link";
import { FormEvent, useEffect, useState } from "react";
import { Boxes, FileCode2, FolderPlus, Hammer, Trash2 } from "lucide-react";

interface ProjectRow {
  id: number;
  name: string;
  description: string;
  createdAt: string;
  updatedAt: string;
  fileCount: number;
  buildCount: number;
}

export default function ProjectsPage() {
  const [rows, setRows] = useState<ProjectRow[] | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const load = async () => {
    const res = await fetch("/api/projects");
    const data = await res.json();
    setRows(data.projects ?? []);
  };

  useEffect(() => {
    load();
  }, []);

  const create = async (e: FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    setBusy(true);
    setError(null);
    const res = await fetch("/api/projects", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, description }),
    });
    const data = await res.json();
    setBusy(false);
    if (!res.ok) {
      setError(data.error ?? "Failed to create project");
      return;
    }
    setName("");
    setDescription("");
    load();
  };

  const remove = async (id: number) => {
    await fetch(`/api/projects/${id}`, { method: "DELETE" });
    load();
  };

  return (
    <div className="mx-auto max-w-5xl px-5 py-10">
      <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-amber">
            workspace
          </p>
          <h1 className="mt-1.5 text-[28px] font-bold tracking-tight">Projects</h1>
          <p className="mt-1 text-[13.5px] text-mut">
            Multi-file roblox-java projects, persisted and buildable in the browser.
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-[320px_1fr]">
        {/* create form */}
        <form
          onSubmit={create}
          className="h-fit rounded-lg border border-line bg-bg1 p-5"
        >
          <div className="flex items-center gap-2">
            <FolderPlus size={16} className="text-amber" />
            <h2 className="text-[15px] font-semibold">New project</h2>
          </div>
          <label className="mt-4 block text-[12px] font-medium text-mut">
            Name
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="my-obby"
              className="mt-1.5 w-full rounded-md border border-line2 bg-bg2 px-3 py-2 font-mono text-[13px] text-ink outline-none transition focus:border-amber/60"
            />
          </label>
          <label className="mt-3 block text-[12px] font-medium text-mut">
            Description <span className="text-dim">(optional)</span>
            <input
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="A spicy obby with moving platforms"
              className="mt-1.5 w-full rounded-md border border-line2 bg-bg2 px-3 py-2 text-[13px] text-ink outline-none transition focus:border-amber/60"
            />
          </label>
          {error && (
            <p className="mt-3 rounded-md border border-coral/30 bg-coral/10 px-3 py-2 text-[12px] text-coral">
              {error}
            </p>
          )}
          <button
            type="submit"
            disabled={busy || !name.trim()}
            className="mt-4 w-full rounded-md bg-amber px-4 py-2 text-[13.5px] font-semibold text-bg0 transition hover:bg-ember disabled:cursor-not-allowed disabled:opacity-40"
          >
            {busy ? "Creating…" : "Create project"}
          </button>
          <p className="mt-3 text-[11.5px] leading-relaxed text-dim">
            Each project starts with a <span className="font-mono text-mut">src/main.js</span>{" "}
            starter file. Imports between files compile to{" "}
            <span className="font-mono text-mut">require()</span>.
          </p>
        </form>

        {/* list */}
        <div>
          {rows === null && (
            <div className="rounded-lg border border-line bg-bg1 p-8 text-center text-sm text-dim">
              Loading projects…
            </div>
          )}
          {rows !== null && rows.length === 0 && (
            <div className="flex flex-col items-center rounded-lg border border-dashed border-line2 bg-bg1/50 px-6 py-14 text-center">
              <Boxes size={28} className="text-dim" />
              <h3 className="mt-3 text-[15px] font-semibold">No projects yet</h3>
              <p className="mt-1 max-w-xs text-[12.5px] text-mut">
                Create your first project to get a multi-file workspace with build
                history and Rojo output.
              </p>
            </div>
          )}
          <ul className="space-y-3">
            {rows?.map((p) => (
              <li
                key={p.id}
                className="group rounded-lg border border-line bg-bg1 p-4 transition hover:border-amber/40"
              >
                <div className="flex items-start justify-between gap-3">
                  <Link href={`/projects/${p.id}`} className="min-w-0 flex-1">
                    <h3 className="truncate font-mono text-[15px] font-semibold text-ink group-hover:text-amber">
                      {p.name}
                    </h3>
                    {p.description && (
                      <p className="mt-0.5 truncate text-[12.5px] text-mut">{p.description}</p>
                    )}
                    <div className="mt-2.5 flex items-center gap-4 font-mono text-[11px] text-dim">
                      <span className="flex items-center gap-1">
                        <FileCode2 size={11} />
                        {p.fileCount} file{p.fileCount === 1 ? "" : "s"}
                      </span>
                      <span className="flex items-center gap-1">
                        <Hammer size={11} />
                        {p.buildCount} build{p.buildCount === 1 ? "" : "s"}
                      </span>
                      <span>updated {new Date(p.updatedAt).toLocaleDateString()}</span>
                    </div>
                  </Link>
                  <button
                    onClick={() => remove(p.id)}
                    title="Delete project"
                    className="rounded-md border border-transparent p-2 text-dim transition hover:border-coral/40 hover:bg-coral/10 hover:text-coral"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
