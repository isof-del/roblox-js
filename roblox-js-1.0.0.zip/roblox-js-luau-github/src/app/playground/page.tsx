"use client";

import dynamic from "next/dynamic";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  Check,
  ChevronDown,
  CircleAlert,
  Copy,
  FileCode2,
  FileJson2,
  Info,
  Library,
  Play,
  Zap,
} from "lucide-react";
import { compileProject } from "@/compiler";
import type { CompileResult } from "@/compiler";
import { SAMPLES } from "@/compiler/samples";
import JSZip from "jszip";

const Editor = dynamic(() => import("@/components/Editor").then((m) => m.Editor), {
  ssr: false,
  loading: () => (
    <div className="flex h-full items-center justify-center text-sm text-dim">
      Loading editor…
    </div>
  ),
});

const LS_KEY = "roblox-java-playground-v1";

function timeAgoLabel(ms: number) {
  return ms < 1 ? "<1 ms" : `${ms.toFixed(1)} ms`;
}

export default function PlaygroundPage() {
  const [code, setCode] = useState<string>(() => SAMPLES[0].code);
  const [sampleId, setSampleId] = useState<string>(SAMPLES[0].id);
  const [result, setResult] = useState<CompileResult | null>(null);
  const [activeTab, setActiveTab] = useState<string>("main.luau");
  const [auto, setAuto] = useState(true);
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Load persisted code
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LS_KEY);
      if (saved) {
        setCode(saved);
        setSampleId("");
      }
    } catch {
      /* no-op */
    }
  }, []);

  const compile = useCallback((src: string) => {
    const res = compileProject(
      [{ name: "main.js", content: src }],
      { projectName: "playground", includeRuntime: true },
    );
    setResult(res);
  }, []);

  // Auto-compile (debounced)
  useEffect(() => {
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      compile(code);
      try {
        localStorage.setItem(LS_KEY, code);
      } catch {
        /* no-op */
      }
    }, auto ? 350 : 999999999);
    return () => {
      if (timer.current) clearTimeout(timer.current);
    };
  }, [code, auto, compile]);

  // Keep tab valid
  useEffect(() => {
    if (result && !result.outputs.some((o) => o.path === activeTab)) {
      setActiveTab(result.outputs[0]?.path ?? "");
    }
  }, [result, activeTab]);

  const activeOutput = useMemo(
    () => result?.outputs.find((o) => o.path === activeTab) ?? null,
    [result, activeTab],
  );

  const errors = result?.diagnostics.filter((d) => d.severity === "error") ?? [];
  const warnings = result?.diagnostics.filter((d) => d.severity === "warning") ?? [];
  const infos = result?.diagnostics.filter((d) => d.severity === "info") ?? [];

  const loadSample = (id: string) => {
    const s = SAMPLES.find((x) => x.id === id);
    if (!s) return;
    setSampleId(id);
    setCode(s.code);
  };

  const copyActive = async () => {
    if (!activeOutput) return;
    await navigator.clipboard.writeText(activeOutput.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1400);
  };

  const downloadZip = async () => {
    if (!result) return;
    const zip = new JSZip();
    for (const o of result.outputs) zip.file(o.path, o.content);
    const blob = await zip.generateAsync({ type: "blob" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "roblox-java-playground.zip";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="mx-auto max-w-[1400px] px-4 py-5">
      {/* toolbar */}
      <div className="mb-4 flex flex-wrap items-center gap-3 rounded-lg border border-line bg-bg1 px-3 py-2.5">
        <div className="relative">
          <select
            value={sampleId}
            onChange={(e) => loadSample(e.target.value)}
            className="appearance-none rounded-md border border-line2 bg-bg2 py-1.5 pl-3 pr-8 font-mono text-[12px] text-ink outline-none transition hover:border-amber/50"
          >
            <option value="" disabled>
              load a sample…
            </option>
            {SAMPLES.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
          <ChevronDown size={13} className="pointer-events-none absolute right-2.5 top-1/2 -translate-y-1/2 text-dim" />
        </div>
        <button
          onClick={() => compile(code)}
          className="flex items-center gap-1.5 rounded-md bg-amber px-3 py-1.5 text-[12.5px] font-semibold text-bg0 transition hover:bg-ember"
        >
          <Play size={13} strokeWidth={2.5} />
          Compile
        </button>
        <label className="flex cursor-pointer items-center gap-1.5 text-[12px] text-mut">
          <input
            type="checkbox"
            checked={auto}
            onChange={(e) => setAuto(e.target.checked)}
            className="accent-[#ffb224]"
          />
          auto-compile
        </label>
        <div className="ml-auto flex items-center gap-2">
          <button
            onClick={copyActive}
            className="flex items-center gap-1.5 rounded-md border border-line2 bg-bg2 px-2.5 py-1.5 text-[12px] text-mut transition hover:border-amber/50 hover:text-amber"
          >
            {copied ? <Check size={13} className="text-mint" /> : <Copy size={13} />}
            {copied ? "copied" : "copy"}
          </button>
          <button
            onClick={downloadZip}
            className="rounded-md border border-line2 bg-bg2 px-2.5 py-1.5 text-[12px] text-mut transition hover:border-amber/50 hover:text-amber"
          >
            download .zip
          </button>
        </div>
      </div>

      <div className="grid gap-4 xl:grid-cols-2">
        {/* input */}
        <div className="flex min-h-[520px] flex-col overflow-hidden rounded-lg border border-line bg-bg1">
          <div className="flex items-center justify-between border-b border-line bg-bg2 px-3 py-2">
            <div className="flex items-center gap-2">
              <FileCode2 size={14} className="text-amber" />
              <span className="font-mono text-[12px] text-mut">src/main.js</span>
            </div>
            <span className="rounded bg-amber/15 px-1.5 py-0.5 font-mono text-[10px] text-amber">
              JavaScript · ES2022
            </span>
          </div>
          <div className="min-h-0 flex-1">
            <Editor value={code} onChange={setCode} lang="js" />
          </div>
        </div>

        {/* output */}
        <div className="flex min-h-[520px] flex-col overflow-hidden rounded-lg border border-line bg-bg1">
          <div className="flex items-center border-b border-line bg-bg2 px-2">
            {result?.outputs.map((o) => (
              <button
                key={o.path}
                onClick={() => setActiveTab(o.path)}
                className={`flex items-center gap-1.5 border-b-2 px-3 py-2 font-mono text-[11.5px] transition ${
                  activeTab === o.path
                    ? "border-amber text-amber"
                    : "border-transparent text-dim hover:text-mut"
                }`}
              >
                {o.kind === "runtime" ? (
                  <Library size={12} />
                ) : o.kind === "config" ? (
                  <FileJson2 size={12} />
                ) : (
                  <FileCode2 size={12} />
                )}
                {o.path}
              </button>
            ))}
          </div>
          <div className="min-h-0 flex-1 overflow-auto">
            {activeOutput ? (
              activeTab.endsWith(".luau") ? (
                <Editor value={activeOutput.content} lang="lua" readOnly />
              ) : (
                <pre className="p-4 font-mono text-[12.5px] leading-relaxed text-ink">
                  {activeOutput.content}
                </pre>
              )
            ) : null}
          </div>
          {/* diagnostics */}
          <div className="max-h-44 overflow-auto border-t border-line bg-bg0/60">
            <div className="flex items-center gap-3 px-3 py-1.5 text-[11px] font-medium text-dim">
              <span className="font-mono uppercase tracking-wider">diagnostics</span>
              <span className="flex items-center gap-1 text-coral">
                <CircleAlert size={11} /> {errors.length}
              </span>
              <span className="flex items-center gap-1 text-amber">
                <AlertTriangle size={11} /> {warnings.length}
              </span>
              <span className="flex items-center gap-1 text-sky">
                <Info size={11} /> {infos.length}
              </span>
            </div>
            {result && result.diagnostics.length === 0 && (
              <p className="px-3 pb-2 font-mono text-[11.5px] text-mint">
                ✓ clean compile — no problems reported
              </p>
            )}
            {result?.diagnostics.map((d, i) => (
              <div
                key={i}
                className="flex items-start gap-2 border-t border-line/50 px-3 py-1.5"
              >
                {d.severity === "error" ? (
                  <CircleAlert size={13} className="mt-0.5 shrink-0 text-coral" />
                ) : d.severity === "warning" ? (
                  <AlertTriangle size={13} className="mt-0.5 shrink-0 text-amber" />
                ) : (
                  <Info size={13} className="mt-0.5 shrink-0 text-sky" />
                )}
                <span className="font-mono text-[11.5px] text-mut">
                  main.js:{d.line}:{d.column}{" "}
                  <span className="text-ink">{d.message}</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* status bar */}
      <div className="mt-3 flex flex-wrap items-center gap-x-5 gap-y-1 rounded-md border border-line bg-bg1 px-3 py-2 font-mono text-[11.5px] text-dim">
        <span className="flex items-center gap-1.5 text-mint">
          <Zap size={12} />
          {result ? `compiled in ${timeAgoLabel(result.timeMs)}` : "—"}
        </span>
        {result && (
          <>
            <span>{result.stats.statements} statements</span>
            <span>{result.stats.expressions} expressions</span>
            <span>{result.stats.locals} locals</span>
            <span>{result.outputs.length} output files</span>
          </>
        )}
        <span className="ml-auto">compiler runs entirely in your browser</span>
      </div>
    </div>
  );
}
