---
name: Bug report
about: Report incorrect compiler or runtime behavior
title: "[Bug] "
labels: bug
assignees: ''
---

## Description

Describe what went wrong.

## JavaScript input

```js
// Minimal reproduction
```

## Expected Luau behavior

Describe what you expected the compiler/runtime to produce or do.

## Actual behavior

Describe what actually happened.

## Environment

- Node.js version:
- Operating system:
- Repository commit/version:

## Additional context

Include generated Luau, diagnostics, or screenshots when useful.
