class Greeter {
  constructor(name) {
    this.name = name;
  }

  greet() {
    return `Hello, ${this.name}!`;
  }
}

const greeter = new Greeter("Roblox");
print(greeter.greet());
