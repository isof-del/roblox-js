# Contributing

Thanks for helping improve the Roblox JavaScript → Luau toolchain.

## Before you start

Please check the existing issues and documentation before opening a new issue. For larger changes, open an issue first so the design can be discussed before implementation.

## Development setup

1. Install Node.js.
2. Clone the repository.
3. Install dependencies:

```bash
npm install
```

4. Start the development app:

```bash
npm run dev
```

## Useful checks

Run the type checker:

```bash
npm run typecheck
```

Run the linter:

```bash
npm run lint
```

Run the compiler scripts:

```bash
npx tsx scripts/test-compiler.ts
npx tsx scripts/test-multi.ts
```

## Compiler changes

When changing JavaScript → Luau behavior, add or update a focused test case where practical. Prefer small, deterministic examples that make the generated Luau easy to inspect.

Please document intentionally unsupported JavaScript features rather than silently producing incorrect output.

## Pull requests

Keep pull requests focused, describe the user-visible behavior change, and include the verification commands you ran.

Do not commit secrets, local environment files, `node_modules`, generated build output, or database files.
